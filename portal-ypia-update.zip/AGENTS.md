# AGENTS.md

Untuk setiap pekerjaan antarmuka (UI), tata letak, dan penyuntingan teks pada proyek Portal Resmi Yayasan Pendidikan Islam Al-Mun'imiyah (YPIA):
1. Baca `DESIGN.md` sebagai acuan arah desain, identitas lembaga, palet warna, tipografi, dan nilai dial (`ENERGY 1 / RHYTHM 2 / MOTION 1`).
2. Gunakan aturan `antislop` (`.agents/skills/antislop/SKILL.md` beserta `antislop-ui`, `antislop-copywriting`, `antislop-human`, `antislop-layoutmobile`, dan `antislop-code`) sebagai penyaring kualitas wajib sebelum mengirimkan hasil.

