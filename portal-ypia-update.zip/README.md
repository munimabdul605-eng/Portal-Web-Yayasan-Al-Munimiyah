# Portal Web Terpadu SI-YAYASAN — Yayasan Pendidikan Islam Al-Mun'imiyah (YPIA)

Portal web terintegrasi yang memvisualisasikan seluruh ekosistem **Yayasan Pendidikan Islam Al-Mun'imiyah (YPIA) Bandung** langsung dari folder Google Drive **`data masukan`** (`157nEr-14sON96VUaWsNkkpetWrMI_bQs`), dirancang menggunakan filosofi desain **Auralis System ("Engineered Softness")**.

## 5 Modul Utama Portal

1. **Beranda (`#beranda`)** — Hero editorial 12 kolom, *SI-YAYASAN Command Center* interaktif (telemetri cepat 5 jenjang PG–SMAIT & visualisasi spektral Tri-Kurikulum), serta *Marquee* 8 Nilai Dasar (`AL-MUN'IMIYAH`).
2. **Profil & Tata Kelola (`#profil`)** — Landasan filosofis, legalitas Kemenkumham RI (`AHU-0019283.AH.01.04.Tahun 2015`), Visi 2030 & 4 Misi, filterable Struktur Organ Yayasan & Kepala Unit (10 pejabat), SOP Disiplin SDM, dan Matriks KPI Guru/Staf.
3. **Unit Pendidikan (`#unit`)** — Eksplorasi 5 jenjang (`PG`, `TK`, `SDIT`, `SMPIT`, `SMAIT`) lengkap dengan proporsi Tri-Kurikulum, target Tahfidz Al-Qur'an, pembiasaan adab harian, muatan sains/koding/robotika/AI, serta SOP Halaqah & Klinik Matrikulasi Tahsin Sore Gratis.
4. **Informasi PPDB & Kalkulator Simulasi Biaya (`#ppdb`)** — Kalkulator otomatis berbasis **Statuta Pasal 9 Ayat (5)** (*mutually exclusive* diskon Statuta + akumulasi diskon Gelombang + opsi Cicilan 3 Termin 0% vs Lunas Ekstra +3% DPP), Tabel Master Biaya, Timeline 3 Gelombang, 7 Langkah Alur PPDB, dan Checklist 12 Dokumen Persyaratan.
5. **Konsultasi AI & Master FAQ (`#konsultasi`)** — Konsol chat interaktif 24 jam bersama **Ustadzah Fatimah (Gem Model A)** lengkap dengan 5 tombol uji skenario satu-klik, ringkasan evaluasi komparasi A/B (Gem A vs Gem B), serta eksplorer Master FAQ (Kategori A–D) & *Objection Handling / Guardrails* (Kategori E).

## Sumber Data Google Drive (`data masukan`)

| Kunci | Nama Dokumen di Google Drive | ID File Drive |
| :--- | :--- | :--- |
| `statuta` | `01_Statuta_Yayasan_Al_Munimiyah` | `1pZZrIK-TrCDAa0TVtLSri85Q_Hx0j-XOSFXXZ6p9ETQ` |
| `biaya` | `02_Tabel_Biaya_dan_Simulasi_Diskon_YPIA` | `181egM0K7R5Omiwf9MK2rY0fP0un_awrh7B5xvfCXQHM` |
| `ppdb` | `03_Timeline_dan_SOP_Seleksi_PPDB_YPIA` | `1qDBl7R79xiJrWJHhUsLqL34HbJWqXd4nwMYn7F_4y9I` |
| `kurikulum` | `04_SOP_Pendidik_dan_Kurikulum_Khas_YPIA` | `1kTIXHnP_0-wS-KwFMnMTAmGFauzqOGZjCgYW7WsirlY` |
| `faq` | `05_Master_FAQ_dan_Objection_Handling_PPDB_YPIA` | `1_BuseUiDsVcd8wa1GlErAw7Lb3vIkhvB5xvfCXQHM` / `1_BuseUiDsVcd8wa1GlErAw7Lb3vIkhvB5C6euKZ2HsM` |
| `ai` | `06_Fase3_System_Prompt_dan_Tabel_Komparatif_Gem_A_vs_Gem_B_YPIA` | `1kZ3-oZbZfUAZPksk9GWf81-1iwBZMNREIwqQvBucXng` |

## Cara Menjalankan

```bash
npm start
# Portal berjalan di http://localhost:3000
```

Opsional — aktifkan LLM Gemini API langsung dengan menambahkan variabel `GEMINI_API_KEY` pada file `.env` (jika tidak diset, portal otomatis menggunakan mesin penalaran lokal yang 100% ter-grounding pada ke-6 dokumen Drive).

