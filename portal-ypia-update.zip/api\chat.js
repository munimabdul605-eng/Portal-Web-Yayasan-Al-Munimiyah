const fs = require('fs');
const path = require('path');
const assistant = require('../lib/assistant');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const body = req.body || {};
    const message = String(body.message || '').trim().slice(0, 2000);
    if (!message) {
      return res.status(400).json({ error: 'Pesan kosong' });
    }

    const history = Array.isArray(body.history)
      ? body.history.filter((h) => h && typeof h.content === 'string').slice(-12)
      : [];

    const kbPath = path.join(process.cwd(), 'public', 'data', 'kb.json');
    let kb = {};
    if (fs.existsSync(kbPath)) {
      kb = JSON.parse(fs.readFileSync(kbPath, 'utf8'));
    }

    const out = await assistant.answer(kb, null, message, history);
    return res.status(200).json(out);
  } catch (err) {
    console.error('API Chat Error:', err);
    return res.status(500).json({ error: err.message });
  }
};

