module.exports = (req, res) => {
  res.status(200).json({
    ok: true,
    engine: process.env.GEMINI_API_KEY ? 'gemini' : 'local',
    timestamp: new Date().toISOString()
  });
};

