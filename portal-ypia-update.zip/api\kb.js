const fs = require('fs');
const path = require('path');

module.exports = (req, res) => {
  try {
    const kbPath = path.join(process.cwd(), 'public', 'data', 'kb.json');
    if (fs.existsSync(kbPath)) {
      const kbData = JSON.parse(fs.readFileSync(kbPath, 'utf8'));
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader('Cache-Control', 's-maxage=60, stale-while-revalidate=300');
      return res.status(200).json(kbData);
    }
    return res.status(404).json({ error: 'kb.json not found' });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

