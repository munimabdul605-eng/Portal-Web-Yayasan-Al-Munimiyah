**YAYASAN PENDIDIKAN ISLAM AL-MUN'IMIYAH (YPIA)**  
**PENYELENGGARA PENDIDIKAN ISLAM TERPADU MULTIJENJANG (PG – TK – SD – SMP – SMA)**  
SK Kemenkumham RI No. AHU-0019283.AH.01.04.Tahun 2015 \| Kampus Terpadu Jl. Pendidikan Terpadu No. 99, Bandung 40292

# **STATUTA DAN PEDOMAN TATA KELOLA YAYASAN PENDIDIKAN ISLAM AL-MUN'IMIYAH PERIODE 2025 – 2030**

**Nomor Dokumen:** 001/STATUTA-YPIA/SK-PB/I/2025

# **MUKADIMAH — LANDASAN FILOSOFIS & SPIRITUAL**

Bismillahirrahmanirrahim. Dengan mengharap ridha Allah Subhanahu wa Ta'ala, Yayasan Pendidikan Islam Al-Mun'imiyah (YPIA) didirikan sebagai wujud tanggung jawab keumatan dalam mencerdaskan kehidupan bangsa melalui penyelenggaraan pendidikan Islam terpadu yang berkesinambungan dari jenjang usia dini hingga menengah atas. Berlandaskan Al-Qur'an, As-Sunnah, Pancasila, dan Undang-Undang Dasar 1945, Yayasan berkomitmen melahirkan generasi Rabbani yang memiliki keteguhan akidah, kemuliaan akhlak, keunggulan akademik, kecakapan kepemimpinan global, serta penguasaan teknologi mutakhir.

# **BAB I — KETENTUAN UMUM, IDENTITAS, DAN KEDUDUKAN**

**Pasal 1: Nama, Tempat Kedudukan, dan Jangka Waktu**  
(1) Yayasan ini bernama 'Yayasan Pendidikan Islam Al-Mun'imiyah', selanjutnya dalam Statuta ini disingkat 'YPIA' atau disebut 'Yayasan'.  
(2) Yayasan berkedudukan pusat di Kampus Terpadu Al-Mun'imiyah Islamic School, Jl. Pendidikan Terpadu No. 99, Kecamatan Arcamanik, Kota Bandung, Provinsi Jawa Barat, Kode Pos 40292\.  
(3) Yayasan didirikan pada tanggal 12 Rabiul Awal 1436 H bertepatan dengan 3 Januari 2015 M untuk jangka waktu yang tidak ditentukan lamanya.

Pasal 2: Legalitas Badan Hukum dan Nomor Induk Lembaga  
(1) Yayasan telah memperoleh pengesahan Badan Hukum berdasarkan Keputusan Menteri Hukum dan Hak Asasi Manusia Republik Indonesia Nomor: AHU-0019283.AH.01.04.Tahun 2015\.  
(2) Akta Pendirian Yayasan tercatat pada Notaris Dr. H. Ahmad Sulaiman, S.H., M.Kn. Nomor 14 Tanggal 3 Januari 2015\.  
(3) Seluruh satuan pendidikan di bawah naungan Yayasan beroperasi dengan Izin Operasional Dinas Pendidikan terkait dan terakreditasi 'A' (Unggul) oleh BAN-PDM.

**Pasal 3: Asas, Nilai Dasar (Core Values), dan Semboyan**  
(1) Yayasan berasaskan Islam Rahmatan lil 'Alamin dengan berpedoman pada Al-Qur'an dan As-Sunnah serta selaras dengan falsafah negara Pancasila.  
(2) Nilai Dasar (Core Values) Yayasan disingkat 'AL-MUN'IMIYAH' dengan pilar nilai utama: Jujur (Integritas), Unggul (Excellence), Beradab (Akhlakul Karimah), Amanah (Accountable), Empati (Peduli Sosial), Disiplin (Tertib Tata Kelola), Adaptif (Inovasi Teknologi), dan Harmonis (Kolaboratif).  
(3) Semboyan pendidikan Yayasan adalah: 'Membina Akhlak Mulia, Merajut Hafalan Al-Qur'an, Menguasai Sains dan Teknologi Masa Depan'.

# **BAB II — VISI, MISI, DAN TUJUAN STRATEGIS**

**Pasal 4: Visi Yayasan**  
(1) Visi Yayasan Pendidikan Islam Al-Mun'imiyah adalah: 'Menjadi Lembaga Pendidikan Islam Terpadu Multijenjang yang Unggul dalam Membentuk Generasi Qur'ani, Berakhlak Mulia, Berprestasi Akademik Global, dan Berwawasan Teknologi pada Tahun 2030'.

**Pasal 5: Misi Yayasan**  
(1) Menyelenggarakan pendidikan Islam terpadu berkesinambungan dari jenjang Playgroup (PG), Taman Kanak-Kanak (TK), Sekolah Dasar (SD), Sekolah Menengah Pertama (SMP), hingga Sekolah Menengah Atas (SMA) dengan sistem penjaminan mutu terstandar.  
(2) Mengintegrasikan kurikulum nasional dengan kurikulum kepesantrenan/tahfidz Al-Qur'an serta pembiasaan adab Islami sehari-hari.  
(3) Menerapkan tata kelola kelembagaan modern berbasis transformasi digital (Smart School Ecosystem) yang transparan, akuntabel, dan responsif terhadap kebutuhan orang tua siswa.  
(4) Mengembangkan potensi minat, bakat, riset sains, kewirausahaan, dan literasi kecerdasan buatan (Artificial Intelligence) bagi peserta didik sesuai tahapan perkembangan psikologisnya.

# **BAB III — ORGANISASI DAN TATA KELOLA YAYASAN**

**Pasal 6: Organ Yayasan dan Pembagian Kewenangan**  
(1) Sesuai Undang-Undang Republik Indonesia Nomor 16 Tahun 2001 juncto Undang-Undang Nomor 28 Tahun 2004 tentang Yayasan, Organ YPIA terdiri atas: (a) Dewan Pembina, (b) Dewan Pengawas, dan (c) Dewan Pengurus.  
(2) Dewan Pembina memegang kewenangan tertinggi meliputi perubahan Anggaran Dasar/Statuta, pengangkatan dan pemberhentian Pengurus/Pengawas, serta penetapan arah kebijakan umum jangka panjang.  
(3) Dewan Pengurus bertanggung jawab penuh atas manajemen operasional harian, pengelolaan sumber daya manusia, keuangan, aset, serta pengawasan mutu akademik seluruh unit sekolah.  
(4) Dewan Pengawas bertugas melakukan pengawasan berkala serta memberi nasihat kepada Pengurus terkait kepatuhan terhadap Statuta, SOP, dan audit keuangan tahunan.

**Tabel 1\. Struktur Organ Yayasan dan Pimpinan Unit Sekolah (Periode 2025–2030)**

| Jabatan / Posisi | Nama Pejabat | Ruang Lingkup Tanggung Jawab Utama |
| :---- | :---- | :---- |
| Ketua Dewan Pembina | Prof. Dr. KH. Abdul Mun'im, M.A. | Penetapan visi strategis, pengesahan Statuta & RKAT Yayasan |
| Ketua Dewan Pengawas | Dr. H. Rahmat Hidayat, S.E., M.Ak., Ak. | Audit kepatuhan tata kelola, pengawasan anggaran & mutu layanan |
| Ketua Umum Yayasan | Dr. H. Farhan Al-Banna, M.Pd. | Pimpinan eksekutif tertinggi operasional seluruh unit pendidikan |
| Sekretaris Yayasan | Hj. Siti Nurhaliza, S.S., M.M. | Tata persuratan, legalitas, humas, & sistem informasi terpadu |
| Bendahara Yayasan | H. Lukman Hakim, S.E., M.Si. | Manajemen keuangan, SPP, beasiswa, dan penggajian SDM |
| Direktur Pendidikan | Dr. Irfan Maulana, M.Pd.I. | Kurikulum terpadu, supervisi kepala sekolah, & mutu tahfidz |
| Kepala PG & TK Islam | Bunda Nisa Khairunnisa, S.Pd.AUD. | Operasional akademik & pengasuhan jenjang Playgroup & TK |
| Kepala SD Islam Terpadu | Ustadz Hendra Wijaya, S.Pd., M.Pd. | Operasional akademik, tahfidz & kesiswaan jenjang SD (Kelas 1-6) |
| Kepala SMP Islam Terpadu | Ustadz M. Zaki Al-Faruq, S.Si., M.Pd. | Operasional akademik, bina karakter & riset jenjang SMP (Kelas 7-9) |
| Kepala SMA Islam Terpadu | Ustadzah Dr. Rina Kartika, M.Sc. | Operasional akademik, persiapan PTN/Luar Negeri jenjang SMA (10-12) |

# **BAB IV — SATUAN PENDIDIKAN & STANDAR KURIKULUM KHAS**

**Pasal 7: Penyelenggaraan Satuan Pendidikan Multijenjang**  
(1) Yayasan menyelenggarakan 5 (lima) jenjang pendidikan formal dan nonformal dalam satu kawasan terpadu (One-Stop Islamic Education Complex) yang terdiri atas: Playgroup (PG), Taman Kanak-Kanak (TK), Sekolah Dasar (SD), Sekolah Menengah Pertama (SMP), dan Sekolah Menengah Atas (SMA).  
(2) Setiap satuan pendidikan menerapkan Kurikulum Nasional (Kurikulum Merdeka) yang diperkaya dengan Kurikulum Khas Yayasan Pendidikan Islam Al-Mun'imiyah (Al-Mun'imiyah Integrated Islamic Curriculum).

**Tabel 2\. Profil Jenjang, Kuota Kelas, Jam Belajar, dan Target Kurikulum Khas / Tahfidz**

| Unit Jenjang | Syarat Usia Minimal (Per 1 Juli) | Rasio & Kuota Per Rombel | Jam Belajar Efektif | Target Lulusan Tahfidz & Program Unggulan |
| :---- | :---- | :---- | :---- | :---- |
| Playgroup (PG) Al-Mun'imiyah | Minimal 3 Tahun | 15 Siswa / Kelas (2 Guru Pendamping) | Senin – Jumat 08.00 – 11.00 WIB | Hafal 15 Surat Pendek Juz 30, Doa Harian, Stimulasi Sensorik-Motorik & Kemandirian Toilet Training. |
| TK Islam (TK A & B) Al-Mun'imiyah | TK A: 4 Tahun; TK B: 5 Tahun | 20 Siswa / Kelas (2 Guru Pendamping) | Senin – Jumat 07.30 – 11.30 WIB | Hafal Surat Pilihan Juz 30 (An-Naba s.d. An-Nas), Tuntas Iqra/Al-Qur'an Dasar, Calistung Ramah Anak. |
| SD Islam Terpadu (SDIT) Al-Mun'imiyah | Minimal 6 Tahun (Tanpa Tes Calistung) | 28 Siswa / Kelas (4 Rombel/Angkatan) | Senin – Jumat 07.00 – 14.30 WIB | Target Hafalan Minimal 2 Juz (Juz 30 & Juz 29), Praktik Ibadah Shalat Dhuha & Dzuhur Berjamaah, Coding Kids. |
| SMP Islam Terpadu (SMPIT) Al-Mun'imiyah | Lulus SD/MI (Maksimal 15 Tahun) | 30 Siswa / Kelas (4 Rombel/Angkatan) | Senin – Jumat 07.00 – 15.30 WIB | Target Hafalan Minimal 3 Juz Baru (Akumulasi 5 Juz), Bilingual Active (Arab-Inggris), Riset Sains & Robotika. |
| SMA Islam Terpadu (SMAIT) Al-Mun'imiyah | Lulus SMP/MTs (Maksimal 18 Tahun) | 30 Siswa / Kelas (4 Rombel/Angkatan) | Senin – Jumat 06.45 – 16.00 WIB | Target Hafalan Minimal 3 Juz Baru (Akumulasi 5-10 Juz), Klinik Persiapan UTBK-SNBT/Beasiswa LN, AI & Entrepreneurship. |

# **BAB V — KEBIJAKAN UMUM PENERIMAAN PESERTA DIDIK BARU (PPDB)**

**Pasal 8: Prinsip dan Jalur Penerimaan Siswa Baru**  
(1) Penerimaan Peserta Didik Baru (PPDB) dilaksanakan secara objektif, transparan, akuntabel, dan terintegrasi satu pintu melalui portal resmi SI-YAYASAN.  
(2) Jalur Penerimaan pada jenjang PG, TK, dan SD menggunakan prinsip observasi kematangan psikologis dan kesiapan belajar (dilarang melakukan tes seleksi baca-tulis-hitung / Calistung untuk masuk SD sesuai regulasi pemerintah).  
(3) Jalur Penerimaan pada jenjang SMP dan SMA terbagi menjadi: (a) Jalur Reguler, (b) Jalur Prestasi Akademik/Sains/Olahraga, (c) Jalur Prestasi Tahfidz Al-Qur'an, dan (d) Jalur Internal Keberlanjutan (Alumni Jenjang Di Bawahnya).

Pasal 9: Kebijakan Beasiswa, Potongan Biaya, dan Keringanan Finansial  
(1) Potongan Alumni Internal (Keberlanjutan Jenjang): Lulusan TK Al-Mun'imiyah yang melanjutkan ke SD Al-Mun'imiyah, lulusan SD ke SMP, serta lulusan SMP ke SMA berhak memperoleh potongan Dana Pengembangan Pendidikan (Uang Pangkal) sebesar 20% (dua puluh persen).  
(2) Potongan Saudara Kandung (Sibling Discount): Calon siswa yang memiliki kakak/adik kandung yang masih aktif bersekolah di unit mana pun di bawah naungan YPIA berhak memperoleh potongan Uang Pangkal sebesar 10% (sepuluh persen) dan potongan SPP bulanan sebesar 5% untuk anak kedua dan seterusnya.  
(3) Beasiswa Prestasi Tahfidz Al-Qur'an (Khusus SMP & SMA): Calon siswa yang memiliki hafalan mutqin minimal 5 Juz dibebaskan 50% Uang Pangkal; hafalan mutqin minimal 10 Juz dibebaskan 100% Uang Pangkal dan potongan SPP 50% selama mempertahankan hafalannya.  
(4) Kuota Afirmasi Yatim & Dhuafa Berprestasi: Yayasan wajib mengalokasikan minimal 5% (lima persen) dari total daya tampung setiap angkatan untuk beasiswa penuh (100% Uang Pangkal & SPP) bagi siswa yatim/dhuafa di sekitar lingkungan sekolah melalui dana ZISWAF Yayasan.  
(5) Ketentuan Tidak Dapat Digabungkan (Mutually Exclusive): Apabila calon siswa memenuhi lebih dari satu kriteria potongan biaya (misalnya Alumni sekaligus Saudara Kandung), maka hanya berlaku satu skema potongan dengan nilai persentase manfaat tertinggi, namun tetap dapat digabungkan dengan Diskon Gelombang Pendaftaran (Early Bird).

# **BAB VI — PENDIDIK, TENAGA KEPENDIDIKAN, DAN KODE ETIK**

**Pasal 10: Kualifikasi dan Standar Kompetensi SDM**  
(1) Setiap Pendidik (Guru) wajib beragama Islam, mampu membaca Al-Qur'an dengan tartil (minimal lulus sertifikasi Tahsin Internal Yayasan), tidak merokok, serta memiliki kualifikasi akademik minimal Sarjana (S-1) atau Diploma Empat (D-IV) yang linier.  
(2) Setiap Pendidik dan Tenaga Kependidikan wajib mengikuti pembinaan ruhiyah (Liqo/Kajian Pekanan Yayasan) setiap hari Jumat sore dan pelatihan kompetensi pedagogik-digital minimal 30 jam pelajaran per semester.  
(3) Yayasan menerapkan sistem informasi kepegawaian terpadu untuk pemantauan kehadiran, penilaian kinerja bulanan (Key Performance Indicators), dan kesejahteraan yang adil.

**Pasal 11: Perlindungan Anak dan Sekolah Ramah Anak (Zero Bullying Policy)**  
(1) Seluruh lingkungan satuan pendidikan di bawah Yayasan Pendidikan Islam Al-Mun'imiyah merupakan kawasan bebas asap rokok, bebas kekerasan fisik maupun verbal, dan bebas perundungan (Zero Tolerance for Bullying).  
(2) Setiap unit sekolah wajib memiliki Tim Pencegahan dan Penanganan Kekerasan (TPPK) serta layanan Bimbingan Konseling Islami yang bekerja sama secara aktif dengan orang tua/wali murid.

# **BAB VII — TRANSFORMASI DIGITAL DAN KETERBUKAAN INFORMASI**

**Pasal 12: Ekosistem Informasi Terpadu (SI-YAYASAN)**  
(1) Yayasan menetapkan Portal Web Terpadu dan Asisten AI Resmi sebagai kanal komunikasi utama bagi orang tua siswa dan masyarakat luas.  
(2) Seluruh dokumen publik meliputi profil unit, rincian biaya pendidikan resmi, jadwal seleksi PPDB, kurikulum khas, dan FAQ wajib dimutakhirkan secara berkala oleh Sekretaris Yayasan bersama Tim IT sebelum tahun ajaran baru dimulai.  
(3) Segala bentuk transaksi pembayaran biaya pendaftaran, uang pangkal, dan SPP bulanan hanya sah apabila dilakukan melalui rekening Virtual Account resmi atas nama 'Yayasan Pendidikan Islam Al-Mun'imiyah'. Yayasan melarang keras pembayaran tunai kepada panitia atau transfer ke rekening pribadi staf.

# **BAB VIII — KETENTUAN PENUTUP DAN PENGESAHAN**

Pasal 13: Pemberlakuan Statuta  
(1) Statuta Yayasan Pendidikan Islam Al-Mun'imiyah ini mulai berlaku sejak tanggal ditetapkan dan menjadi rujukan tertinggi dalam penyusunan Standar Operasional Prosedur (SOP), Peraturan Akademik, serta Pedoman PPDB di seluruh unit sekolah.  
(2) Hal-hal teknis operasional yang belum diatur secara rinci dalam Statuta ini akan ditetapkan lebih lanjut melalui Surat Keputusan Pengurus Yayasan dan Pedoman Teknis masing-masing bidang.

| Ditetapkan di: Kota BandungPada Tanggal: 15 Rajab 1446 H / 15 Januari 2025 MKetua Dewan Pembina YPIA,\[Ditandatangani & Berstempel Basah\]Prof. Dr. KH. Abdul Mun'im, M.A.NIY. 19650312.201501.1.001 | Mengetahui & Mengesahkan Pelaksanaan,Dewan Pengurus Pusat YPIAKetua Umum Pengurus YPIA,\[Ditandatangani & Berstempel Basah\]Dr. H. Farhan Al-Banna, M.Pd.NIY. 19780817.201501.1.002 |
| :---- | :---- |

