**PANITIA PENERIMAAN PESERTA DIDIK BARU (PPDB) TERPADU**  
**YAYASAN PENDIDIKAN ISLAM AL-MUN'IMIYAH (YPIA)**  
**JENJANG PLAYGROUP (PG) – TK ISLAM – SDIT – SMPIT – SMAIT AL-MUN'IMIYAH BANDUNG**  
Sekretariat PPDB: Gedung Pusat Layanan Terpadu Lt. 1, Jl. Pendidikan Terpadu No. 99, Kota Bandung \| WhatsApp Center: 0811-2233-4455

# **STANDAR OPERASIONAL PROSEDUR (SOP) & TIMELINE SELEKSI PENERIMAAN PESERTA DIDIK BARU (PPDB) MULTIJENJANG TAHUN AJARAN 2026/2027**

**Nomor Dokumen:** 003/SOP-PPDB/YPIA/I/2026

# **BAGIAN I. JADWAL & TIMELINE PPDB 3 GELOMBANG (TAHUN AJARAN 2026/2027)**

Penerimaan Peserta Didik Baru (PPDB) Yayasan Pendidikan Islam Al-Mun'imiyah dilaksanakan dalam 3 (tiga) gelombang ditambah 1 (satu) Jalur Khusus Inden/Internal. Pendaftaran pada Gelombang 3 akan otomatis ditutup lebih awal apabila kuota rombongan belajar (rombel) pada unit terkait telah terpenuhi 100%.

| Tahapan Kegiatan PPDB | Jalur Inden Alumni & Prestasi (Khusus) | Gelombang 1 (Early Bird \- Diskon 15% DPP) | Gelombang 2 (Reguler I \- Diskon 8% DPP) | Gelombang 3 (Reguler II \- Tarif Normal) |
| :---- | :---- | :---- | :---- | :---- |
| 1\. Pembukaan & Pengisian Formulir Online (Portal SI-YAYASAN) | 1 – 30 September 2025 | 1 Oktober – 12 Desember 2025 | 5 Januari – 13 Maret 2026 | 1 April – 12 Juni 2026 (Jika Kuota Masih Ada) |
| 2\. Batas Akhir Pembayaran Formulir & Unggah Berkas Digital | 2 Oktober 2025 (Pukul 16.00 WIB) | 13 Desember 2025 (Pukul 16.00 WIB) | 14 Maret 2026 (Pukul 16.00 WIB) | 13 Juni 2026 (Pukul 16.00 WIB) |
| 3\. Pelaksanaan Observasi, Tes Seleksi, Tasmi' & Wawancara Wali | Sabtu, 4 Oktober 2025 (08.00 – 14.00 WIB) | Sabtu, 15 November & 14 Desember 2025 (2 Sesi) | Sabtu, 14 Februari & 15 Maret 2026 (2 Sesi) | Sabtu, 16 Mei & 14 Juni 2026 (2 Sesi) |
| 4\. Sidang Pleno Kelulusan & Penetapan SK Beasiswa Yayasan | 8 Oktober 2025 | 17 Desember 2025 | 18 Maret 2026 | 16 Juni 2026 |
| 5\. Pengumuman Hasil Seleksi (Via Portal Web & WhatsApp Resmi) | 10 Oktober 2025 (Pukul 10.00 WIB) | 19 Desember 2025 (Pukul 10.00 WIB) | 20 Maret 2026 (Pukul 10.00 WIB) | 18 Juni 2026 (Pukul 10.00 WIB) |
| 6\. Periode Daftar Ulang & Pembayaran Tahap 1 (Min. 50% DPP) | 10 – 20 Oktober 2025 | 19 – 30 Desember 2025 (Syarat Diskon 15%) | 20 – 31 Maret 2026 (Syarat Diskon 8%) | 18 – 26 Juni 2026 (Wajib Lunas Tahap 1\) |
| 7\. Pengukuran Seragam Khas & Pengambilan Paket Buku | 15 – 30 Mei 2026 | 15 – 30 Mei 2026 | 1 – 15 Juni 2026 | 22 – 30 Juni 2026 |
| 8\. Masa Pengenalan Lingkungan Sekolah (MPLS) & Hari Pertama KBM | Senin, 13 Juli 2026 | Senin, 13 Juli 2026 | Senin, 13 Juli 2026 | Senin, 13 Juli 2026 |

# **BAGIAN II. KUOTA DAYA TAMPUNG & SYARAT USIA PER JENJANG (PER 1 JULI 2026\)**

| Kode Unit | Nama Satuan Pendidikan | Jumlah Rombel | Kuota Per Kelas | Total Daya Tampung | Batas Usia Minimal / Syarat Kelulusan (Per 1 Juli 2026\) |
| :---- | :---- | :---- | :---- | :---- | :---- |
| PG | Playgroup Islam Al-Mun'imiyah | 2 Kelas | 15 Siswa | 30 Siswa | Usia minimal 3 tahun 0 bulan pada 1 Juli 2026\. |
| TK | TK Islam Al-Mun'imiyah (TK A & TK B) | 4 Kelas (2 TK A, 2 TK B) | 20 Siswa | 80 Siswa | TK A: Minimal 4 tahun 0 bulan. TK B: Minimal 5 tahun 0 bulan. |
| SD | SD Islam Terpadu (SDIT) Al-Mun'imiyah | 4 Kelas | 28 Siswa | 112 Siswa | Prioritas usia \>= 6 tahun 0 bulan. (Usia 5 thn 8 bln – 5 thn 11 bln wajib rekomendasi tertulis Psikolog Profesional). |
| SMP | SMP Islam Terpadu (SMPIT) Al-Mun'imiyah | 4 Kelas (2 Putra, 2 Putri) | 30 Siswa | 120 Siswa | Lulus SD/MI sederajat dan berusia maksimal 15 tahun pada 1 Juli 2026\. |
| SMA | SMA Islam Terpadu (SMAIT) Al-Mun'imiyah | 4 Kelas (Sains & Sosial-Keagamaan) | 30 Siswa | 120 Siswa | Lulus SMP/MTs sederajat dan berusia maksimal 18 tahun pada 1 Juli 2026\. |

# **BAGIAN III. SOP ALUR PENDAFTARAN ONLINE TERPADU (7 LANGKAH SI-YAYASAN)**

**Langkah 1 — Konsultasi Informasi & Simulasi Biaya via Portal / Asisten AI:** Calon wali murid mengakses Portal Resmi Google Sites Yayasan Pendidikan Islam Al-Mun'imiyah, membaca informasi jenjang, serta dapat berkonsultasi interaktif 24 jam melalui fitur 'Asisten PPDB Yayasan Al-Mun'imiyah' (Gemini Custom Gem) untuk menanyakan syarat usia, kurikulum, maupun simulasi potongan biaya.

Langkah 2 — Pengisian Formulir Pendaftaran Terpadu (Google Forms): Calon wali murid mengisi Formulir PPDB Online pada portal sesuai unit tujuan (PG/TK/SD/SMP/SMA), memilih jalur pendaftaran (Reguler/Alumni/Sibling/Prestasi Tahfidz/Afirmasi), serta mengunggah dokumen persyaratan digital.

**Langkah 3 — Penerbitan Nomor Registrasi & Pembayaran Biaya Formulir:** Sistem Spreadsheet Otomasi PPDB mengirimkan pesan konfirmasi berisi Nomor Registrasi Unik (Format: YPIA-26-\[JENJANG\]-\[URUT\]) dan Nomor Virtual Account (VA) Bank Syariah Indonesia (BSI) untuk pembayaran Biaya Formulir (PG/TK: Rp250.000; SD: Rp350.000; SMP: Rp400.000; SMA: Rp450.000).

**Langkah 4 — Verifikasi Berkas & Penjadwalan Kartu Tes/Observasi:** Dalam waktu maksimal 1x24 jam kerja setelah pembayaran formulir terverifikasi oleh Bendahara, Panitia PPDB mengirimkan Kartu Peserta Seleksi beserta jadwal jam kehadiran Observasi/Tes dan Wawancara Wali Murid.

**Langkah 5 — Pelaksanaan Observasi / Tes Seleksi & Wawancara Komitmen:** Calon siswa mengikuti observasi atau tes seleksi luring (offline) di Kampus Terpadu YPIA Bandung sesuai jadwal. Pada saat bersamaan, kedua orang tua/wali mengikuti sesi wawancara keselarasan visi pendidikan dan komitmen finansial.

Langkah 6 — Pengumuman Resmi Kelulusan & SK Potongan/Beasiswa: Hasil seleksi diumumkan melalui Portal SI-YAYASAN dan surat elektronik resmi. Surat Keputusan (SK) kelulusan mencantumkan rincian tagihan bersih setelah dikurangi diskon gelombang dan beasiswa yang disetujui.

**Langkah 7 — Daftar Ulang, Pembayaran Tahap 1, & Penerbitan NIS:** Wali murid dari siswa yang dinyatakan 'Diterima' wajib melakukan pembayaran Daftar Ulang Tahap 1 (Minimal 50% DPP Bersih \+ 100% Paket Seragam/Buku/Kegiatan \+ SPP Juli) melalui Virtual Account resmi paling lambat 7 hari kerja setelah pengumuman. Setelah lunas Tahap 1, siswa resmi memperoleh Nomor Induk Siswa (NIS) YPIA.

# **BAGIAN IV. MATRIKS INSTRUMEN OBSERVASI & TES SELEKSI TIAP JENJANG**

Sesuai amanat Statuta Yayasan Pasal 8 Ayat (2), seleksi masuk jenjang PG, TK, dan SD **DILARANG KERAS** menggunakan tes calistung (baca-tulis-hitung) yang bersifat menggugurkan. Berikut adalah rincian instrumen seleksi tiap jenjang:

| Jenjang Pendidikan | Metode & Durasi Seleksi | Komponen Asesmen Calon Siswa | Materi Wawancara Orang Tua / Wali | Kriteria Kelulusan Utama |
| :---- | :---- | :---- | :---- | :---- |
| Playgroup (PG) & TK Islam | Observasi Ramah Anak (Non-Tes) 45 Menit / Kelompok | 1\. Observasi bermain (motorik kasar & halus)2. Respons instruksi sederhana & sosialisasi3. Cek kemandirian dasar (toilet training) | Pola asuh di rumah, riwayat tumbuh kembang/alergi anak, & kerja sama pembiasaan adab. | Kesiapan sosial-emosional sesuai usia & kesediaan kuota kelas. |
| SD Islam Terpadu (SDIT) | Observasi Kesiapan Belajar SD (TANPA TES CALISTUNG) 60 Menit | 1\. Observasi kematangan psikologis & fokus2. Kemampuan sosial-emosional & komunikasi3. Pemetaan awal mengenal huruf hijaiyah (bukan penentu lulus) | Komitmen mendampingi muraja'ah Al-Qur'an di rumah, keselarasan visi, & kesiapan finansial. | Kematangan usia (\>= 6 thn) & kesiapan psikologis mengikuti KBM SD Full Day. |
| SMP Islam Terpadu (SMPIT) | Tes Seleksi Terstandar 150 Menit | 1\. CBT Akademik Dasar (Literasi, Numerasi, Sains)2. Tes Praktik Baca Al-Qur'an (Tahsin) & Uji Hafalan Juz 303\. Psikotes Minat Bakat & Wawancara Siswa4. Uji Tasmi' 5–10 Juz (Khusus Jalur Beasiswa) | Komitmen tata tertib remaja (bebas gawai saat KBM, bebas rokok/perundungan) & dukungan program tahfidz. | Skor gabungan CBT \>= 70, mampu membaca Al-Qur'an dasar, & rekam jejak akhlak baik. |
| SMA Islam Terpadu (SMAIT) | Tes Seleksi & Peminatan 180 Menit | 1\. CBT Akademik (Matematika, IPA/IPS Terpadu, B. Inggris, PAI)2. Tes Tahsin Al-Qur'an & Uji Hafalan Minimal 2 Juz3. Psikotes Peminatan Karir & Wawancara Kepemimpinan4. Uji Tasmi' 5–10 Juz (Khusus Jalur Beasiswa) | Keselarasan rencana studi lanjut (PTN/Luar Negeri), pengawasan pergaulan remaja, & komitmen finansial. | Skor gabungan CBT \>= 75, lulus tes baca Al-Qur'an tartil, & bebas pelanggaran berat. |

# **BAGIAN V. DAFTAR PERSYARATAN DOKUMEN ADMINISTRASI (CHECKLIST BERKAS)**

| No | Nama Dokumen Persyaratan | Jenjang Wajib | Status Berkas | Ketentuan Validasi Panitia PPDB |
| :---- | :---- | :---- | :---- | :---- |
| 1 | Scan Akta Kelahiran Asli Calon Siswa | Semua Jenjang (PG – SMA) | Wajib Mutlak | Untuk memvalidasi batas usia per tanggal 1 Juli 2026\. |
| 2 | Scan Kartu Keluarga (KK) Terbaru | Semua Jenjang (PG – SMA) | Wajib Mutlak | Sekaligus menjadi bukti klaim Diskon Saudara Kandung (Sibling). |
| 3 | Scan KTP Ayah dan Ibu / Wali Sah | Semua Jenjang (PG – SMA) | Wajib Mutlak | Data identitas penanggung jawab finansial & pembuatan Virtual Account. |
| 4 | Pasfoto Berwarna Terbaru Latar Merah/Biru (3x4) | Semua Jenjang (PG – SMA) | Wajib Mutlak | Berpakaian sopan/rapi (Siswa putri SD-SMA wajib berjilbab rapi). |
| 5 | Kartu Imunisasi Dasar / Riwayat Kesehatan Anak | PG, TK, dan SD | Wajib (PG-SD) / Opsional (SMP-SMA) | Digunakan sebagai data rekam medis Unit Kesehatan Sekolah (UKS). |
| 6 | Surat Rekomendasi Tertulis Psikolog Profesional | Khusus SD (Usia 5 thn 8-11 bln) | Kondisional Wajib | Wajib bagi calon siswa SD yang belum genap 6 tahun pada 1 Juli 2026\. |
| 7 | Scan Rapor 2 Semester Terakhir dari Sekolah Asal | Khusus SMP & SMA | Wajib Mutlak | Rapor Kelas 5 & 6 (untuk SMP) atau Rapor Kelas 8 & 9 (untuk SMA). |
| 8 | Surat Keterangan NISN Aktif dari Sekolah Asal | Khusus SMP & SMA | Wajib Mutlak | Validasi Nomor Induk Siswa Nasional pada sistem Dapodik Kemendikdasmen. |
| 9 | Scan Ijazah / Surat Keterangan Lulus (SKL) | Khusus SMP & SMA | Menyusul (Maks 30 Juni 2026\) | Diserahkan segera setelah pengumuman kelulusan resmi sekolah asal. |
| 10 | Sertifikat Tahfidz / Piagam Kejuaraan Akademik | SMP & SMA (Jalur Beasiswa) | Kondisional (Jalur Prestasi) | Bukti awal sebelum mengikuti Uji Tasmi' / Verifikasi Prestasi YPIA. |
| 11 | Nomor Induk Siswa (NIS) Internal YPIA | SD, SMP, SMA (Jalur Alumni) | Kondisional (Jalur Alumni) | Syarat klaim otomatis Potongan Uang Pangkal Alumni sebesar 20%. |
| 12 | SKTM Kelurahan, Akta Kematian & Foto Rumah | Semua Jenjang (Afirmasi Yatim) | Kondisional (Jalur Afirmasi) | Syarat pengajuan Beasiswa Penuh 100% Yatim/Dhuafa (Kuota 5%). |

# **BAGIAN VI. PROSEDUR PENANGANAN KASUS KHUSUS (INKLUSI ABK RINGAN, WAITING LIST, & MUTASI)**

* **Kebijakan Siswa Berkebutuhan Khusus (Inklusi Terbatas):** Setiap unit sekolah di bawah YPIA menyediakan kuota inklusi terbatas maksimal 2 (dua) siswa per rombongan belajar untuk kategori kebutuhan khusus ringan (Slow Learner ringan atau ADHD ringan yang mandiri). Orang tua wajib menyerahkan hasil asesmen psikolog klinis/dokter tumbuh kembang sejak awal pendaftaran dan bersedia menyediakan Guru Pendamping Khusus (Shadow Teacher) apabila direkomendasikan oleh Tim Psikologi Yayasan.  
* **Prosedur Daftar Tunggu (Waiting List / Cadangan):** Calon siswa yang memenuhi kriteria kelulusan namun mendaftar saat kuota rombel telah penuh akan ditempatkan pada status 'Cadangan Berperingkat'. Apabila terdapat calon siswa lulus yang tidak melakukan daftar ulang hingga batas waktu 7 hari kerja, kursi kosong akan otomatis ditawarkan kepada daftar tunggu urutan teratas.  
* **Penerimaan Siswa Pindahan / Mutasi Tengah Tahun:** Penerimaan siswa mutasi hanya dibuka pada awal Semester Ganjil untuk Kelas 2–5 SD, Kelas 8 SMP, dan Kelas 11 SMA sepanjang masih terdapat kursi kosong. Siswa mutasi wajib mengikuti tes akademik, wawancara adab, serta program klinik matrikulasi Al-Qur'an.

| Ditetapkan di: Kota Bandung, 20 Januari 2026Direktur Pendidikan YPIA,\[Ditandatangani\]Dr. Irfan Maulana, M.Pd.I.NIY. 19820410.201501.1.006 | Mengetahui,Ketua Panitia PPDB Terpadu YPIA,\[Ditandatangani\]Ustadz M. Zaki Al-Faruq, S.Si., M.Pd.NIY. 19861122.201607.1.014 |
| :---- | :---- |

