**DIREKTORAT PENDIDIKAN DAN SUMBER DAYA INSANI**  
**YAYASAN PENDIDIKAN ISLAM AL-MUN'IMIYAH (YPIA)**  
Kampus Terpadu Jl. Pendidikan Terpadu No. 99, Bandung 40292 \| Email: kurikulum@almunimiyah.sch.id

# **STANDAR OPERASIONAL PROSEDUR (SOP) PENDIDIK & TENAGA KEPENDIDIKAN SERTA PEDOMAN KURIKULUM KHAS & TAHFIDZ AL-QUR'AN TAHUN AJARAN 2026/2027**

**Nomor Dokumen:** 004/SOP-KUR-SDM/YPIA/I/2026

# **BAGIAN I — ARSITEKTUR KURIKULUM TERPADU (AL-MUN'IMIYAH INTEGRATED CURRICULUM)**

Seluruh satuan pendidikan di bawah naungan Yayasan Pendidikan Islam Al-Mun'imiyah menerapkan model integrasi 'Tri-Kurikulum' yang memadukan: (1) Kurikulum Nasional (Kurikulum Merdeka Kemendikdasmen), (2) Kurikulum Khas Kepesantrenan & Tahfidz Al-Qur'an Metode Al-Mun'imiyah, serta (3) Kurikulum Kecakapan Global, Sains-Teknologi, dan Literasi Artificial Intelligence (AI).

| Unit Jenjang | Proporsi Muatan Kurikulum | Metode & Target Tahsin / Tahfidz Al-Qur'an | Program Pembiasaan Adab & Ibadah Harian | Muatan Unggulan Sains, Bahasa & Teknologi |
| :---- | :---- | :---- | :---- | :---- |
| Playgroup (PG) (3–4 Tahun) | 70% Karakter & Sensorik; 30% Pengenalan Al-Qur'an | Metode Talqin & Audio-Kinestetik: Hafal 15 Surat Pendek Juz 30, 12 Doa Harian & 10 Hadits Pendek. | Senyum, Salam, Sapa, Salim (4S), Adab makan-minum duduk tangan kanan, Kemandirian Toilet Training. | Sensory Play, Motorik Halus, Storytelling Kisah Nabi, & Kebun Edukasi Cilik. |
| TK Islam (A & B) (4–6 Tahun) | 60% Fondasi Kesiapan SD; 40% Al-Qur'an & Adab | Metode Ummi / Iqra Terpadu: Tuntas Jilid Dasar / Pra-Tahsin, Hafal Juz 30 (An-Naba s.d. An-Nas sesuai kemampuan). | Praktik Wudhu & Shalat Dhuha bersama, Sedekah Jumat Pagi, Antre tertib & merapikan alat bermain. | Calistung Ramah Anak (Melalui Permainan), Pengenalan Kosakata Arab-Inggris Visual. |
| SD Islam Terpadu (Kelas 1–6) | 55% Kurikulum Nasional; 30% Al-Qur'an & Diniyah; 15% STEAM & Coding | Metode Halaqah Berjenjang (Rasio 1 Guru : 10 Siswa): Lulus Sertifikasi Tahsin di Kelas 3, Target Hafalan Mutqin Minimal 2 Juz (Juz 30 & 29). | Shalat Dhuha & Dzuhur Berjamaah, Dzikir Al-Ma'tsurat Pagi, Puasa Sunnah Senin/Kamis (Kelas 4–6). | Coding Kids (Scratch & Blockly), Sains Eksperimen, Bahasa Arab & Inggris Komunikatif. |
| SMP Islam Terpadu (Kelas 7–9) | 50% Kurikulum Nasional; 30% Tahfidz & Tsaqafah; 20% Riset & Bilingual | Metode Halaqah Pagi & Muraja'ah Berpasangan: Target Hafalan Baru Minimal 3 Juz (Akumulasi 5 Juz), Wajib Ujian Tasmi' Sekali Duduk tiap 1 Juz. | Shalat Dhuha, Dzuhur & Ashar Berjamaah, Malam Bina Iman & Taqwa (MABIT) Bulanan, Kultum Tiga Bahasa. | Bilingual Active Days, Robotika & IoT Dasar, Karya Ilmiah Remaja (KIR), & Leadership Camp. |
| SMA Islam Terpadu (Kelas 10–12) | 50% Kurikulum Nasional & UTBK; 25% Tahfidz & Fiqih Kontemporer; 25% AI & Riset Global | Metode Talaqqi & Sanad Tahsin: Target Hafalan Baru Minimal 3 Juz (Akumulasi 5–10 Juz), Program Khusus Takhasus 15–30 Juz. | Qiyamul Lail Terprogram & Mentorship (Bina Pribadi Islam), Khidmah Masyarakat (KKN Siswa SMA). | Literasi AI & Data Science Dasar (Python), Startup/Entrepreneurship, Klinik Intensif PTN & IELTS/TOEFL. |

# **BAGIAN II — SOP PENYELENGGARAAN HALAQAH TAHFIDZ, UJIAN TASMI', & REMEDIAL AL-QUR'AN**

* **Struktur Waktu Halaqah Al-Qur'an Harian:** Seluruh siswa jenjang SD, SMP, dan SMA memulai kegiatan pagi dengan Shalat Dhuha dan Halaqah Al-Qur'an pukul 07.00 – 08.15 WIB (75 menit setiap hari). Rasio pembimbing halaqah adalah maksimal 1 Ustadz/Ustadzah untuk 10–12 siswa guna menjamin ketepatan makharijul huruf dan tajwid.  
* **Standar Mutqin dan Ujian Tasmi' Sekali Duduk:** Siswa tidak diperkenankan menambah hafalan juz baru sebelum lulus Ujian Tasmi' (membaca hafalan 1 juz penuh sekali duduk di hadapan penguji dan orang tua) dengan batas toleransi maksimal 3 (tiga) kali kesalahan teguran tajwid/kelancaran per juz.  
* **Klinik Matrikulasi Al-Qur'an (Bagi Siswa Baru & Mutasi):** Siswa baru jenjang SD, SMP, atau SMA yang belum lancar membaca Al-Qur'an saat masuk tidak digugurkan hak belajarnya, melainkan wajib mengikuti 'Klinik Intensif Tahsin Sore' (3 kali sepekan selama Semester 1\) tanpa dipungut biaya tambahan hingga lulus standar bacaan Al-Qur'an.  
* **Buku Mutaba'ah Digital & Sinergi Orang Tua:** Setiap capaian setoran ayat harian (Ziyadah) dan pengulangan hafalan (Muraja'ah) dicatat oleh guru halaqah pada Buku Mutaba'ah Digital yang terhubung ke akun orang tua. Wali murid wajib mendampingi muraja'ah di rumah minimal 15–20 menit setelah Shalat Maghrib.

# **BAGIAN III — SOP DISIPLIN JAM KERJA, PRESENSI, & PERIZINAN PENDIDIK / TENAGA KEPENDIDIKAN**

| Aspek Operasional SDM | Ketentuan Baku & Batas Waktu | Prosedur Administrasi & Mekanisme Pengganti (Inval) |
| :---- | :---- | :---- |
| 1\. Jam Kehadiran & Kepulangan Harian | • Guru PG & TK: 06.45 – 14.00 WIB• Guru SDIT: 06.30 – 15.15 WIB• Guru SMPIT & SMAIT: 06.30 – 16.15 WIB• Staf TU/Keuangan/IT: 07.00 – 16.00 WIB | Wajib melakukan presensi biometrik (wajah/sidik jari) di gerbang unit masing-masing. Guru piket wajib hadir pukul 06.15 WIB untuk menyambut siswa (Morning Greeting). |
| 2\. Toleransi Keterlambatan & Sanksi | Batas toleransi keterlambatan adalah pukul 06.40 WIB (SD-SMA) atau 06.55 WIB (PG-TK). | • Terlambat \>10 menit: Pemotongan tunjangan kehadiran harian sebesar 25%.• Akumulasi terlambat \>= 4 kali dalam 1 bulan: Surat Peringatan Lisan & pembinaan Kepala Sekolah. |
| 3\. Prosedur Izin Tidak Masuk (Sakit / Urusan Mendesak) | Konfirmasi izin wajib disampaikan minimal pukul 05.30 WIB pada hari H kepada Kepala Sekolah & Wakil Kurikulum. | • Izin sakit \>2 hari wajib melampirkan Surat Keterangan Dokter.• Guru yang izin WAJIB mengirimkan Modul Tugas Mandiri / Lembar Kerja Siswa (LKS) kepada Guru Piket/Inval sebelum pukul 06.30 WIB agar kelas tidak kosong. |
| 4\. Hak Cuti Tahunan, Cuti Melahirkan & Ibadah | • Cuti Tahunan: 12 hari kerja (saat libur semester)• Cuti Melahirkan: 3 bulan penuh (Gaji Pokok 100%)• Cuti Umrah/Haji: Sesuai jadwal resmi Kemenag. | Pengajuan Cuti Melahirkan dan Cuti Ibadah Umrah/Haji wajib diajukan tertulis kepada Direktur SDM minimal 30 hari kalender sebelum keberangkatan. |
| 5\. Kewajiban Pembinaan Ruhiyah & Pelatihan | • Kajian/Liqo Pekanan: Jumat pukul 14.30 – 16.00 WIB• Tahsin Guru: 2x sepekan• Pelatihan Pedagogik & AI: Min. 30 JP / Semester. | Kehadiran pada Liqo Jumat dan Sertifikasi Tahsin Guru menjadi syarat mutlak pencairan Tunjangan Kinerja Semesteran. |

# **BAGIAN IV — STANDAR ADAB BERPAKAIAN, ETIKA KOMUNIKASI WALI MURID, & LARANGAN KERAS**

**Pasal A — Standar Berpakaian Syar'i & Rapi (Dress Code Pendidik):** (1) Pendidik & Staf Putra wajib mengenakan kemeja seragam/batik yayasan yang sopan, celana bahan kain (tidak ketat dan tidak isbal/menutup mata kaki), bersepatu tertutup, rambut rapi, serta mengenakan peci saat memimpin ibadah/halaqah. (2) Pendidik & Staf Putri wajib mengenakan busana muslimah syar'i yang longgar (tidak membentuk lekuk tubuh dan tidak transparan), jilbab menutup dada, memakai kaus kaki, serta bersepatu nyaman.

**Pasal B — SOP Etika Komunikasi dengan Orang Tua / Wali Murid:** (1) Guru wajib merespons pesan WhatsApp/komunikasi wali murid dengan bahasa yang santun, empatik, dan diawali sapaan Islami ('Assalamu'alaikum Ayah/Bunda'). (2) Jam layanan komunikasi efektif wali kelas adalah pukul 07.00 – 19.00 WIB. Pesan di luar jam tersebut (kecuali darurat medis) akan dijawab pada pagi hari berikutnya.

Pasal C — Larangan Keras & Sanksi Pelanggaran Berat (Zero Tolerance): Yayasan memberlakukan sanksi Pemberhentian Tidak Dengan Hormat (PTDH / SP-3 Langsung) terhadap setiap pendidik atau staf yang terbukti melakukan: (a) Kekerasan fisik, perundungan verbal (bullying), atau pelecehan terhadap siswa; (b) Merokok (konvensional maupun elektrik/vape) di area radius 500 meter dari lingkungan kampus; (c) Menerima pungutan liar, gratifikasi uang tunai penentu nilai/kelulusan, atau meminta transfer biaya sekolah ke rekening pribadi; serta (d) Menyebarkan paham radikal/intoleran yang bertentangan dengan Statuta Yayasan.

# **BAGIAN V — MATRIKS INDIKATOR KINERJA UTAMA (KPI) PENILAIAN GURU & STAF**

| Kode KPI | Dimensi Penilaian Kinerja | Bobot (%) | Indikator Target Keberhasilan Semesteran |
| :---- | :---- | :---- | :---- |
| KPI-01 | Kedisiplinan Kehadiran & Adab Ruhiyah | 20% | Kehadiran tepat waktu \>= 97%, kehadiran Liqo Jumat \>= 95%, keteladanan adab & berpakaian syar'i. |
| KPI-02 | Kualitas Pedagogik & Administrasi Ajar | 25% | Kelengkapan Modul Ajar/RPP tepat waktu, pemanfaatan media interaktif/AI, & ketuntasan KBM. |
| KPI-03 | Ketercapaian Target Tahfidz & Adab Siswa | 25% | Minimal 85% siswa binaan mencapai target hafalan semesteran & peningkatan skor adab harian. |
| KPI-04 | Kepuasan Layanan Siswa & Wali Murid | 15% | Responsivitas komunikasi wali kelas, laporan perkembangan siswa berkala, & survei kepuasan \>= 4.3/5.0. |
| KPI-05 | Pengembangan Diri & Kontribusi Lembaga | 15% | Pemenuhan pelatihan 30 JP/semester, pembimbingan lomba siswa, atau kepanitiaan kegiatan yayasan. |

| Ditetapkan di: Kota Bandung, 22 Januari 2026Direktur Pendidikan & SDM YPIA,\[Ditandatangani\]Dr. Irfan Maulana, M.Pd.I.NIY. 19820410.201501.1.006 | Mengesahkan,Ketua Umum Pengurus YPIA,\[Ditandatangani\]Dr. H. Farhan Al-Banna, M.Pd.NIY. 19780817.201501.1.002 |
| :---- | :---- |

