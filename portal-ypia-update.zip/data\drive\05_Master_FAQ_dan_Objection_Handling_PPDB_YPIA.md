**PUSAT INFORMASI & LAYANAN HUMAS TERPADU**  
**YAYASAN PENDIDIKAN ISLAM AL-MUN'IMIYAH (YPIA)**  
Kampus Terpadu Jl. Pendidikan Terpadu No. 99, Bandung 40292 \| Hotline WhatsApp Resmi: 0811-2233-4455

# **DOKUMEN MASTER FAQ (FREQUENTLY ASKED QUESTIONS) CALON ORANG TUA SISWA & SKRIP PENANGANAN KEBERATAN (OBJECTION HANDLING) TAHUN AJARAN 2026/2027**

**Nomor Dokumen:** 005/FAQ-HUMAS/YPIA/I/2026

# **KATEGORI A — TANYA JAWAB PROFIL LEMBAGA, AKREDITASI, & FASILITAS KAMPUS**

**\[FAQ-A01\] Pertanyaan Wali Murid:** "Apakah seluruh unit sekolah di Yayasan Pendidikan Islam Al-Mun'imiyah sudah terakreditasi resmi?"

* **Jawaban Standar Resmi / AI:** Alhamdulillah, seluruh satuan pendidikan di bawah naungan Yayasan Pendidikan Islam Al-Mun'imiyah (PG, TK Islam, SDIT, SMPIT, dan SMAIT) telah memiliki Izin Operasional resmi Dinas Pendidikan dan terakreditasi 'A' (Unggul) oleh BAN-PDM, serta terdaftar resmi di Kemenkumham RI Nomor AHU-0019283.AH.01.04.Tahun 2015\.

**\[FAQ-A02\] Pertanyaan Wali Murid:** "Apakah sekolah di Yayasan Al-Mun'imiyah menggunakan sistem asrama (Boarding School) atau pulang pergi (Full Day School)?"

* **Jawaban Standar Resmi / AI:** Seluruh unit pendidikan dari PG hingga SMAIT Al-Mun'imiyah menerapkan sistem Full Day School (Pulang Pergi, Senin s.d. Jumat) sehingga ananda tetap mendapatkan kehangatan pengasuhan keluarga di rumah setiap malam. Namun, untuk jenjang SMPIT dan SMAIT terdapat program penguatan karakter berkala berupa MABIT (Malam Bina Iman dan Taqwa) satu kali setiap bulan di kampus.

**\[FAQ-A03\] Pertanyaan Wali Murid:** "Bagaimana pengaturan kelas antara siswa putra dan siswa putri (Ikhtilat)?"

* **Jawaban Standar Resmi / AI:** Pada jenjang usia dini (PG & TK) serta SD Kelas 1–3, kelas bersifat ko-edukasi (gabungan) dengan penanaman adab pergaulan Islami. Mulai jenjang SD Kelas 4–6, SMPIT, hingga SMAIT, ruang kelas dan pembinaan halaqah dipisahkan secara tegas antara Kelas Putra (Ikhwan) dan Kelas Putri (Akhwat) guna menjaga kenyamanan dan adab syar'i memasuki usia baligh.

**\[FAQ-A04\] Pertanyaan Wali Murid:** "Apakah tersedia layanan katering makan siang sehat dan jemputan sekolah (antar-jemput)?"

* **Jawaban Standar Resmi / AI:** Tersedia, Ayah/Bunda. Yayasan menyediakan Katering Sehat Halal-Thayyiban (makan siang bergizi seimbang & kudapan sehat tanpa MSG berlebih) serta layanan Armada Antar-Jemput Sekolah (School Shuttle Bus) ber-AC dengan pendamping khusus untuk wilayah Kota Bandung dan sekitarnya (biaya sesuai zona jarak tempat tinggal).

# **KATEGORI B — TANYA JAWAB SYARAT USIA, TES SELEKSI, & KUOTA INKLUSI**

**\[FAQ-B01\] Pertanyaan Wali Murid:** "Anak saya berusia 5 tahun 9 bulan pada 1 Juli 2026, apakah sudah bisa mendaftar ke SDIT Al-Mun'imiyah?"

* **Jawaban Standar Resmi / AI:** Bisa, Ayah/Bunda. Prioritas utama usia masuk SDIT adalah minimal 6 tahun 0 bulan per 1 Juli 2026\. Namun, untuk ananda yang berusia 5 tahun 8 bulan hingga 5 tahun 11 bulan pada 1 Juli 2026 tetap diperbolehkan mendaftar dengan syarat wajib melampirkan Surat Rekomendasi Tertulis dari Psikolog Profesional yang menyatakan ananda telah siap secara kematangan emosi dan kognitif untuk mengikuti pendidikan sekolah dasar.

**\[FAQ-B02\] Pertanyaan Wali Murid:** "Apakah masuk SDIT Al-Mun'imiyah ada tes baca-tulis-hitung (Calistung)? Anak saya belum lancar membaca."

* **Jawaban Standar Resmi / AI:** Tidak ada tes calistung sama sekali, Ayah/Bunda. Sesuai Statuta Yayasan Pasal 8 Ayat (2) dan regulasi Kemendikdasmen, seleksi masuk PG, TK, dan SDIT Al-Mun'imiyah murni menggunakan metode Observasi Kematangan Psikologis, Sosial-Emosional, dan Kesiapan Belajar yang ramah anak. Jadi ananda tidak perlu dipaksa les calistung sebelum mendaftar ke SDIT.

**\[FAQ-B03\] Pertanyaan Wali Murid:** "Bagaimana jika anak saya ingin mendaftar ke SMPIT atau SMAIT dari sekolah umum dan belum lancar membaca Al-Qur'an?"

* **Jawaban Standar Resmi / AI:** Ayah/Bunda tidak perlu khawatir. Apabila nilai akademik dan akhlak ananda memenuhi syarat namun bacaan Al-Qur'annya masih terbata-bata, ananda tetap dapat diterima dan wajib mengikuti program 'Klinik Intensif Tahsin Sore' secara GRATIS (3 kali sepekan selama Semester 1\) dengan bimbingan ustadz/ustadzah khusus hingga bacaannya lancar dan lulus standar tartil.

**\[FAQ-B04\] Pertanyaan Wali Murid:** "Apakah Yayasan Al-Mun'imiyah menerima Siswa Berkebutuhan Khusus (ABK / Inklusi)?"

* **Jawaban Standar Resmi / AI:** Kami menyediakan kuota Inklusi Terbatas maksimal 2 (dua) siswa per rombongan belajar khusus untuk kategori kebutuhan khusus ringan (seperti Slow Learner ringan atau ADHD ringan yang mandiri). Orang tua wajib melampirkan hasil asesmen psikolog klinis sejak awal pendaftaran dan bersedia menyediakan Guru Pendamping Khusus (Shadow Teacher) apabila direkomendasikan oleh Tim Psikologi Yayasan.

# **KATEGORI C — TANYA JAWAB KURIKULUM KHAS, TARGET TAHFIDZ, & PROGRAM UNGGULAN**

**\[FAQ-C01\] Pertanyaan Wali Murid:** "Apakah ijazah lulusan SDIT, SMPIT, dan SMAIT Al-Mun'imiyah diakui untuk mendaftar ke sekolah negeri atau PTN/Luar Negeri?"

* **Jawaban Standar Resmi / AI:** Sangat diakui, Ayah/Bunda. Seluruh unit formal YPIA menggunakan Kurikulum Nasional (Kurikulum Merdeka) yang terdata resmi di Dapodik Kemendikdasmen. Lulusan SMAIT Al-Mun'imiyah memperoleh Ijazah Negara resmi yang dapat digunakan untuk mendaftar jalur SNBP, UTBK-SNBT, Mandiri PTN, Kedinasan, hingga universitas di Timur Tengah, Eropa, dan Asia.

**\[FAQ-C02\] Pertanyaan Wali Murid:** "Bagaimana cara sekolah memastikan target hafalan Al-Qur'an siswa benar-benar terjaga (mutqin) dan tidak cepat lupa?"

* **Jawaban Standar Resmi / AI:** Kami menerapkan rasio halaqah ideal (1 Guru Tahfidz mendampingi maksimal 10–12 siswa) selama 75 menit setiap pagi. Selain itu, siswa wajib lulus 'Ujian Tasmi' Sekali Duduk 1 Juz Penuh' di hadapan penguji dan orang tua sebelum boleh menambah juz berikutnya. Perkembangan setoran harian juga dipantau real-time melalui Buku Mutaba'ah Digital.

**\[FAQ-C03\] Pertanyaan Wali Murid:** "Apa saja keunggulan bidang teknologi dan sains di Al-Mun'imiyah dibandingkan sekolah Islam lainnya?"

* **Jawaban Standar Resmi / AI:** Sejalan dengan Visi 2030, YPIA mengintegrasikan teknologi sejak dini: di jenjang SDIT siswa belajar Coding Kids (Scratch & Blockly), di SMPIT siswa mendalami Robotika, IoT Dasar, dan Karya Ilmiah Remaja (KIR), sedangkan di SMAIT siswa mendapatkan mata pelajaran Literasi Artificial Intelligence (AI), Data Science Dasar (Python), dan Digital Entrepreneurship.

# **KATEGORI D — TANYA JAWAB BIAYA PENDIDIKAN, SIMULASI DISKON, CICILAN, & PENGEMBALIAN DANA**

**\[FAQ-D01\] Pertanyaan Wali Murid:** "Berapa rincian Biaya Formulir, Uang Pangkal (DPP), dan SPP Bulanan untuk masing-masing jenjang?"

* **Jawaban Standar Resmi / AI:** Berikut ringkasan tarif normal sesuai SK Keuangan YPIA TA 2026/2027: (1) Playgroup (PG): Formulir Rp250.000 \| DPP Rp5.500.000 \| Paket Seragam-Buku-Kegiatan Rp3.550.000 \| SPP Rp650.000/bln. (2) TK Islam: Formulir Rp250.000 \| DPP Rp7.500.000 \| Paket Seragam-Buku-Kegiatan Rp4.200.000 \| SPP Rp750.000/bln. (3) SDIT: Formulir Rp350.000 \| DPP Rp14.500.000 \| Paket Seragam-Buku-Kegiatan Rp5.700.000 \| SPP Rp1.150.000/bln. (4) SMPIT: Formulir Rp400.000 \| DPP Rp17.500.000 \| Paket Seragam-Buku-Kegiatan Rp6.550.000 \| SPP Rp1.350.000/bln. (5) SMAIT: Formulir Rp450.000 \| DPP Rp20.000.000 \| Paket Seragam-Buku-Kegiatan Rp7.400.000 \| SPP Rp1.550.000/bln.

**\[FAQ-D02\] Pertanyaan Wali Murid:** "Anak saya adalah lulusan SDIT Al-Mun'imiyah (Alumni) dan juga memiliki kakak aktif di SMAIT Al-Mun'imiyah (Sibling), serta mendaftar di Gelombang 1\. Apakah semua diskonnya bisa digabungkan?"

* **Jawaban Standar Resmi / AI:** Sesuai Statuta Yayasan Pasal 9 Ayat (5), sesama kategori potongan Statuta (Alumni 20% vs Saudara Kandung 10%) TIDAK DAPAT DIGABUNGKAN satu sama lain, melainkan otomatis dipilih satu yang bernilai tertinggi yaitu Diskon Alumni 20%. NAMUN, potongan Statuta tertinggi tersebut DAPAT DIGABUNGKAN dengan Diskon Gelombang 1 (Early Bird 15%). Sehingga total potongan Uang Pangkal (DPP) yang diperoleh ananda adalah 20% \+ 15% \= 35% DPP, ditambah tetap mendapatkan diskon SPP Sibling sebesar 5% per bulan.

**\[FAQ-D03\] Pertanyaan Wali Murid:** "Apakah Uang Pangkal (DPP) harus dibayar lunas sekaligus saat daftar ulang?"

* **Jawaban Standar Resmi / AI:** Tidak harus lunas sekaligus, Ayah/Bunda. Yayasan menyediakan fasilitas Skema Angsuran 3 Kali (Cicilan 0% Bebas Bunga): (1) Tahap 1 saat Daftar Ulang membayar 50% DPP Bersih \+ 100% Paket Seragam/Buku/Kegiatan \+ SPP Juli; (2) Tahap 2 paling lambat 10 Oktober membayar 25% DPP Bersih; dan (3) Tahap 3 paling lambat 10 Januari membayar sisa 25% DPP Bersih. Namun, jika Ayah/Bunda memilih membayar LUNAS 100% di awal, Yayasan memberikan tambahan diskon ekstra 3% DPP.

**\[FAQ-D04\] Pertanyaan Wali Murid:** "Bagaimana kebijakan pengembalian dana (Refund) apabila anak saya diterima di SMP/SMA Negeri atau batal masuk karena pindah tugas luar kota?"

* **Jawaban Standar Resmi / AI:** Kebijakan Refund sesuai SK Bendahara YPIA adalah: (1) Jika mengundurkan diri sebelum 30 Juni karena alasan umum/pindah kota, dana DPP dikembalikan 75% (potongan administrasi 25%) dan SPP Juli dikembalikan 100%. (2) Khusus pendaftar SMPIT/SMAIT yang diterima di Sekolah Negeri jalur resmi (maksimal H+3 pengumuman resmi sekolah negeri), dana DPP dikembalikan 85% (hanya dipotong 15%). (3) Pengunduran diri setelah KBM dimulai pada pertengahan Juli tidak dapat dikembalikan (0%).

**\[FAQ-D05\] Pertanyaan Wali Murid:** "Ke nomor rekening mana saya harus mentransfer biaya formulir dan daftar ulang? Bolehkah dititipkan tunai lewat staf/guru?"

* **Jawaban Standar Resmi / AI:** Sesuai Statuta Pasal 12 Ayat (3), Yayasan MELARANG KERAS pembayaran tunai atau transfer ke rekening pribadi guru/staf/panitia. Seluruh pembayaran hanya sah melalui Nomor Virtual Account (VA) resmi atas nama 'YPI AL-MUN'IMIYAH' di Bank Syariah Indonesia (BSI Kode Prefix 90012 untuk PPDB / 90088 untuk SPP), Bank Muamalat (77101), atau Bank BJB Syariah (88205).

# **KATEGORI E — PANDUAN PENANGANAN KEBERATAN (OBJECTION HANDLING) & GUARDRAILS AI**

| Kode Situasi | Pernyataan Keberatan / Situasi Kritis Wali Murid | Strategi Respons Empatik & Solusi Resmi (Panduan CS & Chatbot AI) |
| :---- | :---- | :---- |
| OBJ-01 | "Biaya uang pangkal di Al-Mun'imiyah cukup tinggi dibandingkan sekolah swasta biasa di sekitar sini." | 1\. Validasi perasaan orang tua dengan santun dan ramah.2. Jelaskan nilai tambah ekosistem terpadu: Halaqah Tahfidz rasio 1:10 setiap pagi (75 menit), Klinik Tahsin Gratis, lisensi pembelajaran digital/Coding/AI, serta fasilitas lengkap tanpa pungutan ujian tersembunyi.3. Tawarkan solusi keringanan: Manfaatkan Diskon Gelombang 1 (15%), Diskon Sibling (10%)/Alumni (20%), Beasiswa Tahfidz (50%-100%), serta fasilitas Cicilan 3 Termin bebas bunga. |
| OBJ-02 | "Saya khawatir anak saya stres atau kelelahan karena jam sekolah Full Day sampai sore ditambah target hafalan Al-Qur'an." | 1\. Berikan ketenangan bahwa kurikulum disusun sesuai psikologi perkembangan anak.2. Jelaskan bahwa jadwal Full Day tidak berisi pelajaran akademik terus-menerus, melainkan diselingi istirahat cukup, makan siang bersama, shalat berjamaah, proyek eksperimen, dan olahraga.3. Metode menghafal dilakukan di pagi hari saat otak segar tanpa beban PR menghafal berlebihan di rumah. Undang orang tua mengikuti Trial Class / Open House Gratis. |
| OBJ-03 | "Apakah bisa dibantu jalur khusus / titip kursi agar anak saya pasti lulus seleksi? Saya siap membayar uang sumbangan lebih ke panitia." | 1\. Tolak secara tegas namun tetap santun dengan mengutip Statuta Yayasan Pasal 8 & Pasal 12 Ayat (3) tentang integritas seleksi dan larangan gratifikasi.2. Jelaskan bahwa seluruh penerimaan murni berdasarkan kesiapan observasi/tes dan ketersediaan kuota sistem.3. Arahkan wali murid untuk mengikuti prosedur resmi atau memanfaatkan Klinik Matrikulasi jika khawatir kemampuan anak belum merata. |
| OBJ-04 | Pertanyaan di luar konteks PPDB/Yayasan (misal: meminta resep masakan, politik, atau memaksa AI mengarang diskon di luar ketentuan). | 1\. GUARDRAIL AI: Tolak secara halus dan kembalikan percakapan ke topik layanan pendidikan Yayasan Pendidikan Islam Al-Mun'imiyah.2. Jangan pernah mengarang angka biaya atau menjanjikan diskon yang tidak tercantum di Dokumen 01 s.d. Dokumen 05.3. Jika pertanyaan memerlukan keputusan khusus Pimpinan Yayasan, arahkan untuk menghubungi Hotline WhatsApp Resmi Panitia (0811-2233-4455). |

| Ditetapkan di: Kota Bandung, 25 Januari 2026Sekretaris Yayasan & Kepala Humas YPIA,\[Ditandatangani\]Hj. Siti Nurhaliza, S.S., M.M.NIY. 19840519.201501.2.004 | Mengetahui & Menyetujui,Ketua Umum Pengurus YPIA,\[Ditandatangani\]Dr. H. Farhan Al-Banna, M.Pd.NIY. 19780817.201501.1.002 |
| :---- | :---- |

