/**
 * Portal Web Resmi Yayasan Pendidikan Islam Al-Mun'imiyah (YPIA)
 * Mengelola tema Terang/Gelap, animasi gulir & sorot sentuhan, pratinjau 5 jenjang,
 * kalkulator biaya, FAQ, layanan pesan, serta aksesibilitas keyboard (R-32).
 */
(function () {
  const R = window.YPIACore.formatRp;
  const esc = (s) =>
    String(s ?? '')
      .replace(/\s*—\s*/g, ': ')
      .replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  let KB = null;
  let lastFocusedEl = null;
  let revealObserver = null;
  let quotaAnimated = false;
  const spotlightBound = new WeakSet();
  const prefersReducedMotion = () =>
    Boolean(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  const TAHFIDZ_TARGETS = {
    PG: 'Hafal 15 Surat Pendek Juz 30 & Doa Harian',
    TK: 'Hafal Surat Pilihan Juz 30 (An-Naba s.d. An-Nas) & Pra-Tahsin Iqra',
    SD: 'Minimal 2 Juz Mutqin (Juz 30 & 29) Bersanad',
    SMP: 'Minimal 3 Juz Baru (Akumulasi 5 Juz Mutqin Bersanad)',
    SMA: 'Minimal 3 Juz Baru (Akumulasi 5–10 Juz Mutqin Bersanad)',
  };

  const UNGGULAN_PROGRAMS = {
    PG: 'Stimulasi Sensorik-Motorik & Kemandirian Toilet Training',
    TK: 'Eksplorasi Sains Anak, Literasi-Numerasi & Calistung Ramah Anak',
    SD: 'Shalat Berjamaah, Coding Kids & Bahasa Arab-Inggris Komunikatif',
    SMP: 'Bilingual Active Days, Robotika-IoT Dasar & Riset Remaja (KIR)',
    SMA: 'AI & Python Dasar, Entrepreneurship & Klinik Intensif PTN/IELTS',
  };

  const state = {
    heroUnitCode: 'SD',
    faqCategory: 'ALL',
    faqQuery: '',
    chatHistory: [],
    liveQuotaStats: [
      { code: 'PG', label: "Playgroup (PG) Al-Mun'imiyah", rombel: '2 Rombel (@15 Siswa)', filled: 3, total: 30 },
      { code: 'TK', label: 'TK Islam (TK A & TK B)', rombel: '4 Rombel (@20 Siswa)', filled: 3, total: 80 },
      { code: 'SD', label: "SDIT Al-Mun'imiyah", rombel: '4 Rombel (@28 Siswa)', filled: 6, total: 112 },
      { code: 'SMP', label: "SMPIT Al-Mun'imiyah", rombel: '4 Rombel (@30 Siswa)', filled: 5, total: 120 },
      { code: 'SMA', label: "SMAIT Al-Mun'imiyah", rombel: '4 Rombel (@30 Siswa)', filled: 5, total: 120 },
    ],
  };

  // Murni 5 Berkas Data Master Acuan Utama
  const MASTER_DOCS = [
    {
      title: 'Dokumen 01: Statuta Yayasan',
      subtitle: "Akta Pendirian & Ketetapan Dasar Tata Kelola Yayasan Pendidikan Islam Al-Mun'imiyah",
    },
    {
      title: 'Dokumen 02: Tabel Biaya & Kebijakan Keringanan',
      subtitle: 'Rincian Biaya Pendidikan TA 2026/2027 & Ketentuan Beasiswa Statuta Pasal 9 Ayat (5)',
    },
    {
      title: 'Dokumen 03: Petunjuk Teknis & SOP Seleksi PPDB',
      subtitle: 'Jadwal 3 Gelombang, Alur Pendaftaran & Persyaratan Administrasi Calon Peserta Didik',
    },
    {
      title: 'Dokumen 04: Standar Pendidik & Kurikulum Khas',
      subtitle: 'Standar Mutu Tenaga Pendidik, Halaqah Tahfidz Bersanad & Muatan Sains-Teknologi',
    },
    {
      title: 'Dokumen 05: Panduan Tanya Jawab & Layanan Informasi',
      subtitle: 'Pedoman Resmi Layanan Informasi Publik, Pertanyaan Umum (FAQ) & Rekening VA Resmi',
    },
  ];

  // =====================================================================
  // PENGALIH TEMA TERANG / GELAP (R-21 & R-34)
  // =====================================================================
  const MOON_ICON_PATHS = '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"></path>';
  const SUN_ICON_PATHS = '<circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"></path>';

  function syncThemeButtonUI() {
    const isDark = document.documentElement.classList.contains('dark');
    const btn = document.getElementById('btn-theme-toggle');
    const icon = document.getElementById('theme-toggle-icon');
    const label = document.getElementById('theme-toggle-label');
    if (icon) icon.innerHTML = isDark ? SUN_ICON_PATHS : MOON_ICON_PATHS;
    if (label) label.textContent = isDark ? 'Terang' : 'Gelap';
    if (btn) {
      btn.setAttribute('aria-pressed', isDark ? 'true' : 'false');
      btn.setAttribute('aria-label', isDark ? 'Ubah tema ke mode terang' : 'Ubah tema ke mode gelap');
    }
  }

  function initThemeToggle() {
    syncThemeButtonUI();
    const btn = document.getElementById('btn-theme-toggle');
    if (!btn) return;
    btn.addEventListener('click', () => {
      const nextDark = !document.documentElement.classList.contains('dark');
      document.documentElement.classList.toggle('dark', nextDark);
      document.documentElement.classList.toggle('light', !nextDark);
      try {
        localStorage.setItem('ypia-theme', nextDark ? 'dark' : 'light');
      } catch (e) {}
      syncThemeButtonUI();
    });
  }

  // =====================================================================
  // MOTION ENGINE: SOROT SENTUHAN / KURSOR, GULIR & PROGRESS (MOTION 2)
  // =====================================================================
  function bindCardSpotlights(root = document) {
    const cards = root.querySelectorAll('.nextra-card');
    cards.forEach((card) => {
      if (spotlightBound.has(card)) return;
      spotlightBound.add(card);
      let touchTimer = null;

      const updateCoords = (clientX, clientY) => {
        const rect = card.getBoundingClientRect();
        card.style.setProperty('--mx', `${Math.round(clientX - rect.left)}px`);
        card.style.setProperty('--my', `${Math.round(clientY - rect.top)}px`);
      };

      card.addEventListener(
        'pointermove',
        (e) => {
          if (e.pointerType === 'touch') return;
          updateCoords(e.clientX, e.clientY);
        },
        { passive: true }
      );

      card.addEventListener(
        'pointerdown',
        (e) => {
          updateCoords(e.clientX, e.clientY);
          card.classList.add('is-touch-active');
          if (touchTimer) clearTimeout(touchTimer);
          touchTimer = setTimeout(() => card.classList.remove('is-touch-active'), 420);
        },
        { passive: true }
      );
    });
  }

  const REVEAL_SELECTOR = '.reveal-on-scroll, .reveal-text, .reveal-row';
  const SECTION_IDS = ['beranda', 'profil', 'unit', 'ppdb', 'konsultasi'];
  const SECTION_META = {
    beranda: { kicker: 'Menu 01 · Beranda Utama', title: "Yayasan Pendidikan Islam Al-Mun'imiyah" },
    profil: { kicker: 'Menu 02 · Profil & Tata Kelola', title: 'Legalitas Badan Hukum & Struktur Kepemimpinan' },
    unit: { kicker: 'Menu 03 · Unit Pendidikan', title: 'Lima Jenjang Terakreditasi A (Unggul)' },
    ppdb: { kicker: 'Menu 04 · Informasi PPDB TA 2026/2027', title: 'Biaya Pendidikan, Beasiswa & Pendaftaran Online' },
    konsultasi: { kicker: 'Menu 05 · Konsultasi & Layanan', title: 'Asisten Informasi, FAQ & Rekening VA Resmi' },
  };
  let currentActiveNav = 'beranda';

  function syncSlidingPill(container, activeEl, indicatorSelector, activeClassOnContainer) {
    if (!container || !activeEl) return;
    const ind = container.querySelector(indicatorSelector);
    if (!ind) return;
    if (container.offsetParent === null) {
      ind.style.opacity = '0';
      return;
    }

    const next = {
      x: activeEl.offsetLeft,
      y: activeEl.offsetTop,
      w: activeEl.offsetWidth,
      h: activeEl.offsetHeight,
    };

    const prev = container._pillCache;
    if (prev && !prefersReducedMotion() && container._pillRecreated) {
      ind.style.transition = 'none';
      ind.style.transform = `translate3d(${prev.x}px, ${prev.y}px, 0)`;
      ind.style.width = `${prev.w}px`;
      ind.style.height = `${prev.h}px`;
      ind.style.opacity = '1';
      void ind.offsetWidth;
      ind.style.transition = '';
    }
    container._pillRecreated = false;
    container._pillCache = next;

    ind.style.transform = `translate3d(${next.x}px, ${next.y}px, 0)`;
    ind.style.width = `${next.w}px`;
    ind.style.height = `${next.h}px`;
    ind.style.opacity = '1';
    if (activeClassOnContainer) container.classList.add(activeClassOnContainer);
  }

  function setActiveNav(navId) {
    currentActiveNav = navId;
    document.querySelectorAll('[data-nav]').forEach((a) => {
      a.classList.toggle('active', a.getAttribute('data-nav') === navId);
    });
    const desktopNav = document.getElementById('desktop-nav');
    const activeDesktopLink = desktopNav ? desktopNav.querySelector(`[data-nav="${navId}"]`) : null;
    if (desktopNav && activeDesktopLink) {
      syncSlidingPill(desktopNav, activeDesktopLink, '#nav-active-indicator', 'has-nav-pill');
    }
  }

  function flushVisibleReveals() {
    const vh = window.innerHeight || 800;
    const atBottom = window.scrollY + vh >= document.documentElement.scrollHeight - 48;
    const feeBody = document.getElementById('fee-master-tbody');
    const feeVisible = feeBody && (feeBody.getBoundingClientRect().top <= vh * 0.94 || atBottom);

    document.querySelectorAll('.reveal-ready:not(.is-visible)').forEach((el) => {
      const rect = el.getBoundingClientRect();
      if (rect.top <= vh * 0.89 || atBottom || (feeVisible && el.classList.contains('reveal-row'))) {
        el.classList.add('is-visible');
        if (revealObserver) revealObserver.unobserve(el);
      }
    });
  }

  function observeReveals(root = document) {
    const targets = root.querySelectorAll(REVEAL_SELECTOR);
    if (!targets.length) return;

    if (prefersReducedMotion() || typeof window.IntersectionObserver !== 'function') {
      targets.forEach((el) => {
        el.classList.remove('reveal-ready');
        el.classList.add('is-visible');
      });
      return;
    }

    if (!revealObserver) {
      revealObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              if (entry.target.classList.contains('reveal-row')) {
                document.querySelectorAll('#fee-master-tbody tr.reveal-row.reveal-ready').forEach((r) => {
                  r.classList.add('is-visible');
                  revealObserver.unobserve(r);
                });
              } else {
                entry.target.classList.add('is-visible');
                revealObserver.unobserve(entry.target);
              }
            }
          });
        },
        { threshold: 0.1, rootMargin: '0px 0px -10% 0px' }
      );
    }

    const vh = window.innerHeight || 800;
    const atBottom = window.scrollY + vh >= document.documentElement.scrollHeight - 48;
    const feeBody = document.getElementById('fee-master-tbody');
    const feeVisible = feeBody && (feeBody.getBoundingClientRect().top <= vh * 0.94 || atBottom);

    targets.forEach((el) => {
      if (el.classList.contains('is-visible')) return;
      const rect = el.getBoundingClientRect();
      if (rect.top <= vh * 0.89 || atBottom || (feeVisible && el.classList.contains('reveal-row'))) {
        el.classList.add('is-visible');
      } else {
        el.classList.add('reveal-ready');
        revealObserver.observe(el);
      }
    });
  }

  function countUpElement(el, target, suffix, duration = 740) {
    if (!el || prefersReducedMotion()) {
      if (el) el.textContent = `${target} ${suffix}`;
      return;
    }
    const start = performance.now();
    const tick = (now) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      const val = Math.round(target * eased);
      el.textContent = `${val} ${suffix}`;
      if (t < 1) window.requestAnimationFrame(tick);
      else el.textContent = `${target} ${suffix}`;
    };
    window.requestAnimationFrame(tick);
  }

  function animateQuotaBars(force = false) {
    const fills = document.querySelectorAll('#ppdb-quota-chart .quota-bar-fill');
    if (!fills.length) return;

    const totalAll = state.liveQuotaStats.reduce((s, q) => s + q.total, 0);
    const filledAll = state.liveQuotaStats.reduce((s, q) => s + q.filled, 0);
    const remAll = Math.max(0, totalAll - filledAll);
    const elTotal = document.getElementById('quota-summary-total');
    const elFilled = document.getElementById('quota-summary-filled');
    const elRem = document.getElementById('quota-summary-remaining');

    if (prefersReducedMotion() || force) {
      fills.forEach((bar) => {
        const s = bar.getAttribute('data-target-scale') || '1';
        bar.style.transform = `scaleX(${s})`;
      });
      if (elTotal) elTotal.textContent = `${totalAll} Kursi`;
      if (elFilled) elFilled.textContent = `${filledAll} Siswa`;
      if (elRem) elRem.textContent = `${remAll} Kursi`;
      quotaAnimated = true;
      return;
    }

    const chartEl = document.getElementById('ppdb-quota-chart');
    if (!chartEl) return;
    const rect = chartEl.getBoundingClientRect();
    if (rect.top <= (window.innerHeight || 800) * 0.92 && !quotaAnimated) {
      quotaAnimated = true;
      countUpElement(elTotal, totalAll, 'Kursi');
      countUpElement(elFilled, filledAll, 'Siswa');
      countUpElement(elRem, remAll, 'Kursi');
      fills.forEach((bar, idx) => {
        const s = bar.getAttribute('data-target-scale') || '0.1';
        setTimeout(() => {
          bar.style.transform = `scaleX(${s})`;
        }, idx * 80);
      });
    }
  }

  function updateOverlapChoreography() {
    const heroShell = document.querySelector('.hero-banner-shell') || document.querySelector('.hero-depth-stage');
    const stacks = document.querySelectorAll('.stack-section > .stack-inner');
    if (prefersReducedMotion()) {
      if (heroShell) heroShell.style.setProperty('--hero-scroll', '0');
      stacks.forEach((inner) => {
        inner.classList.remove('is-receding');
        inner.style.setProperty('--exit-p', '0');
      });
      return;
    }

    if (heroShell) {
      const heroProgress = Math.min(1, Math.max(0, window.scrollY / 440));
      heroShell.style.setProperty('--hero-scroll', heroProgress.toFixed(3));
    }

    const vh = window.innerHeight || 800;
    stacks.forEach((inner) => {
      const parentRect = inner.parentElement.getBoundingClientRect();
      const exitP = Math.min(1, Math.max(0, (vh * 0.88 - parentRect.bottom) / (vh * 0.72)));
      inner.style.setProperty('--exit-p', exitP.toFixed(3));
      inner.classList.toggle('is-receding', exitP > 0.005);
    });
  }

  let smoothScrollRaf = 0;
  let navTransitionToken = 0;
  let navTimers = [];

  function clearNavTimers() {
    navTimers.forEach((id) => clearTimeout(id));
    navTimers = [];
  }

  function cancelSmoothScroll() {
    if (smoothScrollRaf) {
      window.cancelAnimationFrame(smoothScrollRaf);
      smoothScrollRaf = 0;
    }
  }

  function triggerSectionArrival(targetEl) {
    if (!targetEl || prefersReducedMotion()) return;
    targetEl.classList.remove('section-arrived');
    void targetEl.offsetWidth;
    targetEl.classList.add('section-arrived');
    navTimers.push(setTimeout(() => targetEl.classList.remove('section-arrived'), 580));
  }

  function replaySectionEntrance(targetEl, direction) {
    if (!targetEl || prefersReducedMotion()) return;
    const isHero = targetEl.id === 'beranda';
    const enterClass = direction === 'backward' ? 'section-entering-backward' : 'section-entering-forward';

    document.querySelectorAll('.section-entering-forward, .section-entering-backward, .hero-entry-wrap').forEach((s) => {
      s.classList.remove('section-entering-forward', 'section-entering-backward', 'hero-entry-wrap');
    });

    if (isHero) {
      const heroStage = targetEl.querySelector('.hero-depth-stage');
      if (heroStage) {
        heroStage.classList.add('hero-entry-wrap', enterClass);
        heroStage.querySelectorAll('.hero-anim-meta, .hero-anim-headline, .hero-anim-copy, .hero-anim-cta').forEach((node) => {
          node.style.animation = 'none';
          void node.offsetWidth;
          node.style.animation = '';
        });
      }
    } else {
      targetEl.classList.add(enterClass);
    }

    const items = targetEl.querySelectorAll(REVEAL_SELECTOR);
    items.forEach((item) => {
      if (revealObserver) revealObserver.unobserve(item);
      item.classList.remove('is-visible');
      item.classList.add('reveal-ready');
    });
    if (targetEl.id === 'ppdb') {
      quotaAnimated = false;
      document.querySelectorAll('#ppdb-quota-chart .quota-bar-fill').forEach((b) => {
        b.style.transform = 'scaleX(0)';
      });
    }
    void targetEl.offsetWidth;
    window.requestAnimationFrame(() => {
      observeReveals(targetEl);
      flushVisibleReveals();
      animateQuotaBars();
    });

    navTimers.push(
      setTimeout(() => {
        targetEl.classList.remove('section-entering-forward', 'section-entering-backward', 'hero-entry-wrap');
      }, 680)
    );
  }

  function smoothScrollToTarget(targetId) {
    const el = document.getElementById(targetId);
    if (!el) return;
    const targetTop = targetId === 'beranda' ? 0 : Math.max(0, Math.round(el.getBoundingClientRect().top + window.scrollY - 74));

    if (prefersReducedMotion()) {
      window.scrollTo({ top: targetTop, behavior: 'auto' });
      return;
    }

    cancelSmoothScroll();
    const startY = window.scrollY;
    const distance = targetTop - startY;
    if (Math.abs(distance) < 4) {
      triggerSectionArrival(el);
      return;
    }

    const duration = Math.min(720, Math.max(380, Math.abs(distance) * 0.28));
    const startTime = performance.now();

    const step = (now) => {
      const progress = Math.min(1, (now - startTime) / duration);
      const eased = progress < 0.5 ? 4 * progress * progress * progress : 1 - Math.pow(-2 * progress + 2, 3) / 2;
      window.scrollTo({ top: startY + distance * eased, behavior: 'auto' });
      if (progress < 1) {
        smoothScrollRaf = window.requestAnimationFrame(step);
      } else {
        smoothScrollRaf = 0;
        flushVisibleReveals();
        animateQuotaBars();
        triggerSectionArrival(el);
      }
    };
    smoothScrollRaf = window.requestAnimationFrame(step);
  }

  function navigateToSection(targetId) {
    const el = document.getElementById(targetId);
    if (!el) return;
    const sheet = document.getElementById('page-transition-sheet');
    const curIdx = SECTION_IDS.indexOf(currentActiveNav);
    const nextIdx = SECTION_IDS.indexOf(targetId);

    if (prefersReducedMotion() || !sheet || nextIdx === -1 || curIdx === nextIdx) {
      smoothScrollToTarget(targetId);
      if (nextIdx !== -1) setActiveNav(targetId);
      return;
    }

    cancelSmoothScroll();
    clearNavTimers();
    const token = ++navTransitionToken;
    const isBackward = nextIdx < curIdx;
    const meta = SECTION_META[targetId] || { kicker: 'Membuka Bagian', title: targetId };

    setActiveNav(targetId);

    const kickerEl = document.getElementById('pts-kicker');
    const titleEl = document.getElementById('pts-title');
    if (kickerEl) kickerEl.textContent = meta.kicker;
    if (titleEl) titleEl.textContent = meta.title;

    sheet.className = 'page-transition-sheet';
    sheet.style.transition = 'none';
    sheet.style.transform = isBackward ? 'translate3d(0, -106%, 0)' : 'translate3d(0, 106%, 0)';
    sheet.style.visibility = 'visible';
    void sheet.offsetWidth;
    sheet.style.transition = '';
    sheet.style.transform = '';
    sheet.classList.add('is-covering');

    navTimers.push(
      setTimeout(() => {
        if (token !== navTransitionToken) return;
        const targetTop = targetId === 'beranda' ? 0 : Math.max(0, Math.round(el.getBoundingClientRect().top + window.scrollY - 74));
        window.scrollTo({ top: targetTop, behavior: 'instant' });

        const docEl = document.documentElement;
        const maxScroll = Math.max(1, docEl.scrollHeight - window.innerHeight);
        const ratio = Math.min(1, Math.max(0, window.scrollY / maxScroll));
        const bar = document.getElementById('scroll-progress-bar');
        if (bar) bar.style.transform = `scaleX(${ratio.toFixed(4)})`;

        updateOverlapChoreography();

        navTimers.push(
          setTimeout(() => {
            if (token !== navTransitionToken) return;
            replaySectionEntrance(el, isBackward ? 'backward' : 'forward');
            sheet.classList.remove('is-covering');
            sheet.classList.add(isBackward ? 'is-exiting-down' : 'is-exiting-up');

            navTimers.push(
              setTimeout(() => {
                if (token !== navTransitionToken) return;
                sheet.className = 'page-transition-sheet';
                sheet.style.visibility = '';
              }, 460)
            );
          }, 70)
        );
      }, 360)
    );
  }

  function initScrollEngine() {
    const bar = document.getElementById('scroll-progress-bar');
    let ticking = false;

    const onFrame = () => {
      ticking = false;
      const docEl = document.documentElement;
      const maxScroll = Math.max(1, docEl.scrollHeight - window.innerHeight);
      const ratio = Math.min(1, Math.max(0, window.scrollY / maxScroll));
      if (bar) bar.style.transform = `scaleX(${ratio.toFixed(4)})`;

      const y = window.scrollY + 180;
      let current = 'beranda';
      for (const id of SECTION_IDS) {
        const el = document.getElementById(id);
        if (el && el.offsetTop <= y) current = id;
      }
      if (window.scrollY > 120 && window.scrollY + window.innerHeight >= docEl.scrollHeight - 24) {
        current = SECTION_IDS[SECTION_IDS.length - 1];
      }
      if (current !== currentActiveNav) {
        setActiveNav(current);
      }

      updateOverlapChoreography();
      flushVisibleReveals();
      animateQuotaBars();
    };

    const resyncAllSlidingPills = () => {
      setActiveNav(currentActiveNav);
      const heroTabs = document.getElementById('hero-unit-tabs');
      const heroActive = heroTabs ? heroTabs.querySelector('[data-hero-unit].is-active') : null;
      if (heroTabs && heroActive) syncSlidingPill(heroTabs, heroActive, '.tab-sliding-indicator');
      const faqTabs = document.getElementById('faq-cat-tabs');
      const faqActive = faqTabs ? faqTabs.querySelector('[data-faq-cat][aria-pressed="true"]') : null;
      if (faqTabs && faqActive) syncSlidingPill(faqTabs, faqActive, '.tab-sliding-indicator');
    };

    window.addEventListener(
      'scroll',
      () => {
        if (!ticking) {
          ticking = true;
          window.requestAnimationFrame(onFrame);
        }
      },
      { passive: true }
    );
    window.addEventListener('wheel', cancelSmoothScroll, { passive: true });
    window.addEventListener('touchstart', cancelSmoothScroll, { passive: true });
    window.addEventListener(
      'resize',
      () => {
        updateOverlapChoreography();
        flushVisibleReveals();
        resyncAllSlidingPills();
      },
      { passive: true }
    );

    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(resyncAllSlidingPills);
    }

    document.addEventListener('click', (e) => {
      const anchor = e.target.closest('a[href^="#"]');
      if (!anchor) return;
      const href = anchor.getAttribute('href');
      if (!href || href.length < 2) return;
      const targetId = href.slice(1);
      if (targetId === 'main-content') return;
      const targetEl = document.getElementById(targetId);
      if (!targetEl) return;
      e.preventDefault();
      if (window.history && window.history.replaceState) {
        window.history.replaceState(null, '', href);
      }
      navigateToSection(targetId);
    });

    setActiveNav('beranda');
    onFrame();
  }

  const DOC_KEYS = ['statuta', 'biaya', 'ppdb', 'kurikulum', 'faq'];

  function getMasterDocsWithUrls() {
    const files = (KB && KB.drive && KB.drive.files) || {};
    return MASTER_DOCS.map((d, idx) => {
      const key = DOC_KEYS[idx];
      const match = (key && files[key]) || {};
      return {
        ...d,
        url: match.url || 'https://drive.google.com/drive/folders/157nEr-14sON96VUaWsNkkpetWrMI_bQs',
      };
    });
  }

  function renderMarkdown(md) {
    const lines = String(md || '').replace(/\s*—\s*/g, ': ').split(/\r?\n/);
    let html = '';
    let inTable = false;
    let inList = false;
    const inline = (txt) =>
      esc(txt)
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        .replace(/`([^`]+)`/g, '<code>$1</code>');

    for (const raw of lines) {
      const line = raw.trim();
      if (line.startsWith('|') && line.endsWith('|')) {
        if (inList) {
          html += '</ul>';
          inList = false;
        }
        const cells = line
          .slice(1, -1)
          .split('|')
          .map((c) => c.trim());
        if (cells.every((c) => /^:?-+:?$/.test(c))) continue;
        if (!inTable) {
          inTable = true;
          html += '<div class="chat-table-wrap"><table><thead><tr>' + cells.map((c) => `<th>${inline(c)}</th>`).join('') + '</tr></thead><tbody>';
        } else {
          html += '<tr>' + cells.map((c) => `<td>${inline(c)}</td>`).join('') + '</tr>';
        }
        continue;
      } else if (inTable) {
        html += '</tbody></table></div>';
        inTable = false;
      }

      if (/^[-*•]\s+/.test(line) || /^\d+\.\s+/.test(line)) {
        if (!inList) {
          html += '<ul>';
          inList = true;
        }
        html += `<li>${inline(line.replace(/^([-*•]|\d+\.)\s+/, ''))}</li>`;
      } else {
        if (inList) {
          html += '</ul>';
          inList = false;
        }
        if (line) html += `<p>${inline(line)}</p>`;
      }
    }
    if (inTable) html += '</tbody></table></div>';
    if (inList) html += '</ul>';
    return html;
  }

  // =====================================================================
  // A. BERANDA & EKSPLORASI INTERAKTIF LIMA JENJANG
  // =====================================================================
  function renderHeroUnitShowcase(animateDir = null) {
    const tabsEl = document.getElementById('hero-unit-tabs');
    const panelEl = document.getElementById('hero-unit-panel');
    if (!tabsEl || !panelEl || !KB || !KB.units || !KB.units.length) return;

    const units = KB.units;
    const shortLabels = { PG: 'Playgroup', TK: 'TK Islam', SD: 'SDIT', SMP: 'SMPIT', SMA: 'SMAIT' };
    const activeUnit = units.find((u) => u.code === state.heroUnitCode) || units[0];
    const currentIdx = units.findIndex((u) => u.code === activeUnit.code);
    state.heroUnitCode = activeUnit.code;

    tabsEl._pillRecreated = true;
    tabsEl.classList.add('has-sliding-pill');
    tabsEl.innerHTML =
      '<span class="tab-sliding-indicator" aria-hidden="true"></span>' +
      units
        .map(
          (u) => `
      <button
        type="button"
        role="tab"
        data-hero-unit="${esc(u.code)}"
        aria-selected="${u.code === state.heroUnitCode ? 'true' : 'false'}"
        class="tab-btn ${u.code === state.heroUnitCode ? 'is-active' : ''}">
        ${esc(shortLabels[u.code] || u.code)}
      </button>
    `
        )
        .join('');

    const activeTabBtn = tabsEl.querySelector('[data-hero-unit].is-active');
    if (activeTabBtn) syncSlidingPill(tabsEl, activeTabBtn, '.tab-sliding-indicator');

    const bindTabs = Array.from(tabsEl.querySelectorAll('[data-hero-unit]'));
    bindTabs.forEach((btn, idx) => {
      btn.addEventListener('click', () => {
        const nextCode = btn.getAttribute('data-hero-unit');
        if (nextCode && nextCode !== state.heroUnitCode) {
          const dir = idx >= currentIdx ? 'next' : 'prev';
          state.heroUnitCode = nextCode;
          renderHeroUnitShowcase(dir);
        }
      });
      btn.addEventListener('keydown', (e) => {
        if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
        e.preventDefault();
        const dir = e.key === 'ArrowRight' ? 'next' : 'prev';
        const nextIdx = dir === 'next' ? (idx + 1) % bindTabs.length : (idx - 1 + bindTabs.length) % bindTabs.length;
        const target = bindTabs[nextIdx];
        state.heroUnitCode = target.getAttribute('data-hero-unit');
        renderHeroUnitShowcase(dir);
        const refocused = tabsEl.querySelector(`[data-hero-unit="${state.heroUnitCode}"]`);
        if (refocused) refocused.focus();
      });
    });

    panelEl.innerHTML = `
      <div class="flex flex-wrap items-start justify-between gap-3">
        <div class="min-w-0">
          <h3 class="text-base sm:text-lg font-semibold text-ink-primary">${esc(activeUnit.nama)}</h3>
          <p class="text-xs text-ink-muted mt-0.5">Usia Masuk: ${esc(activeUnit.statuta.usia)}</p>
        </div>
        <span class="badge-accent max-w-full">${esc(activeUnit.kuota.rombel)}</span>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
        <div class="p-3.5 rounded-2xl border border-hairline bg-[var(--bg-surface)] space-y-1">
          <span class="text-ink-muted font-medium block">Jam Belajar Efektif</span>
          <strong class="text-ink-primary font-semibold block">${esc(activeUnit.statuta.jam)}</strong>
        </div>
        <div class="p-3.5 rounded-2xl border border-[var(--accent-brand-border)] bg-[var(--accent-brand-soft)] space-y-1">
          <span class="text-accent-brand font-semibold block">Target Hafalan</span>
          <strong class="text-ink-primary font-semibold block">${esc(TAHFIDZ_TARGETS[activeUnit.code] || activeUnit.statuta.target)}</strong>
        </div>
        <div class="p-3.5 rounded-2xl border border-hairline bg-[var(--bg-surface)] space-y-1">
          <span class="text-ink-muted font-medium block">Muatan Unggulan</span>
          <strong class="text-ink-primary font-semibold block">${esc(UNGGULAN_PROGRAMS[activeUnit.code])}</strong>
        </div>
      </div>

      <div class="pt-2 border-t border-hairline flex flex-wrap items-center justify-between gap-3 text-xs">
        <div>
          <span class="text-ink-muted">SPP Bulanan: </span>
          <strong class="font-mono font-semibold text-ink-primary">${R(activeUnit.biaya.spp)}</strong>
        </div>
        <a href="#ppdb" class="font-semibold text-accent-brand hover:underline">
          Lihat Rincian Biaya &amp; Jadwal PPDB &rarr;
        </a>
      </div>
    `;

    if (animateDir && !prefersReducedMotion()) {
      panelEl.classList.remove('showcase-slide-next', 'showcase-slide-prev');
      void panelEl.offsetWidth;
      panelEl.classList.add(animateDir === 'prev' ? 'showcase-slide-prev' : 'showcase-slide-next');
    }
  }

  function renderBeranda() {
    if (!KB || !KB.yayasan) return;
    const y = KB.yayasan;
    const skEl = document.getElementById('hero-sk');
    const visiEl = document.getElementById('hero-visi');
    if (skEl && y.sk) skEl.textContent = y.sk;
    if (visiEl && y.visi) visiEl.textContent = y.visi;
    renderHeroUnitShowcase(null);
  }

  // =====================================================================
  // B. PROFIL & TATA KELOLA
  // =====================================================================
  function renderProfil() {
    if (!KB || !KB.yayasan) return;
    const y = KB.yayasan;

    const addrEl = document.getElementById('profil-address');
    if (addrEl && y.address) addrEl.textContent = y.address;

    const gridEl = document.getElementById('profil-struktur-grid');
    if (!gridEl) return;

    const list = y.struktur || [];
    if (!list.length) {
      gridEl.innerHTML = `<div class="nextra-card text-sm text-ink-secondary md:col-span-2 lg:col-span-3">Data struktur kepemimpinan yayasan belum tersedia pada basis data.</div>`;
      return;
    }

    gridEl.innerHTML = list
      .map((s, idx) => {
        const isKepala = /^Kepala|^Koordinator/i.test(s.jabatan);
        const delay = (idx % 3) * 60;
        const badgeClass = isKepala
          ? 'badge-accent'
          : 'badge-pill !border-[var(--accent-brand-border)] !text-[var(--accent-brand-ink)]';
        return `
        <article class="nextra-card flex flex-col justify-between gap-4 reveal-on-scroll" style="--stagger-delay: ${delay}ms;">
          <div class="space-y-2.5">
            <span class="${badgeClass} w-fit">
              ${esc(s.jabatan)}
            </span>
            <h3 class="text-base font-semibold text-ink-primary">${esc(s.nama)}</h3>
          </div>
          <p class="text-xs text-ink-secondary leading-relaxed border-t border-[var(--accent-brand-border)] pt-3">${esc(s.tugas)}</p>
        </article>
      `;
      })
      .join('');

    bindCardSpotlights(gridEl);
    observeReveals(gridEl);
  }

  // =====================================================================
  // C. UNIT PENDIDIKAN (5 Kartu Seragam dengan 3 Informasi Utama)
  // =====================================================================
  function renderUnit() {
    if (!KB || !KB.units) return;
    const gridEl = document.getElementById('unit-cards-grid');
    if (!gridEl) return;

    const units = KB.units || [];
    if (!units.length) {
      gridEl.innerHTML = `<div class="nextra-card text-sm text-ink-secondary md:col-span-2 lg:col-span-3">Data satuan pendidikan belum tersedia pada basis data.</div>`;
      return;
    }

    gridEl.innerHTML = units
      .map((u, idx) => {
        const delay = (idx % 3) * 60;
        return `
      <article class="nextra-card flex flex-col justify-between gap-6 reveal-on-scroll" style="--stagger-delay: ${delay}ms;">
        <div class="space-y-4">
          <div class="flex flex-wrap items-start justify-between gap-2">
            <div class="min-w-0">
              <h3 class="typo-h3">${esc(u.nama)}</h3>
              <p class="text-xs text-ink-muted mt-1">Usia Masuk: ${esc(u.statuta.usia)}</p>
            </div>
            <span class="badge-accent max-w-full">${esc(u.kuota.rombel)}</span>
          </div>

          <dl class="space-y-2.5 border-t border-hairline pt-4 text-xs">
            <div class="sub-surface p-3.5 space-y-1">
              <dt class="font-semibold text-ink-muted">1. Jam Belajar Efektif</dt>
              <dd class="text-sm font-semibold text-ink-primary">${esc(u.statuta.jam)}</dd>
            </div>

            <div class="notice-accent rounded-2xl p-3.5 space-y-1">
              <dt class="font-semibold">2. Target Hafalan Al-Qur'an</dt>
              <dd class="text-sm font-semibold text-ink-primary">${esc(TAHFIDZ_TARGETS[u.code] || u.statuta.target)}</dd>
            </div>

            <div class="sub-surface p-3.5 space-y-1">
              <dt class="font-semibold text-ink-muted">3. Muatan Unggulan</dt>
              <dd class="text-sm font-semibold text-ink-primary">${esc(UNGGULAN_PROGRAMS[u.code])}</dd>
            </div>
          </dl>
        </div>

        <div class="pt-4 border-t border-hairline flex items-center justify-between gap-3 text-xs">
          <div>
            <span class="text-ink-muted block">SPP Bulanan</span>
            <strong class="text-sm font-mono font-semibold text-ink-primary">${R(u.biaya.spp)}</strong>
          </div>
          <a href="#ppdb" class="btn-with-icon btn-with-icon-sm group no-underline" title="Lihat Biaya &amp; Jadwal ${esc(u.nama)}">
            <span class="relative z-10 transition-all duration-500 whitespace-nowrap">
              Lihat Biaya &amp; Jadwal
            </span>
            <div class="btn-icon-circle" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="5" y1="12" x2="19" y2="12"></line>
                <polyline points="12 5 19 12 12 19"></polyline>
              </svg>
            </div>
          </a>
        </div>
      </article>
    `;
      })
      .join('');

    bindCardSpotlights(gridEl);
    observeReveals(gridEl);
  }

  // =====================================================================
  // D. INFORMASI PPDB (Tabel Biaya, Timeline 3 Gelombang, Checklist Berkas, Kuota)
  // =====================================================================
  function renderLiveQuotaChart() {
    const chartEl = document.getElementById('ppdb-quota-chart');
    if (!chartEl) return;

    const totalAll = state.liveQuotaStats.reduce((s, q) => s + q.total, 0);
    const filledAll = state.liveQuotaStats.reduce((s, q) => s + q.filled, 0);
    const remAll = Math.max(0, totalAll - filledAll);

    const elTotal = document.getElementById('quota-summary-total');
    const elFilled = document.getElementById('quota-summary-filled');
    const elRem = document.getElementById('quota-summary-remaining');
    const elBadge = document.getElementById('quota-badge-summary');
    if (elTotal) elTotal.textContent = `${totalAll} Kursi`;
    if (elFilled) elFilled.textContent = `${filledAll} Siswa`;
    if (elRem) elRem.textContent = `${remAll} Kursi`;
    if (elBadge) elBadge.innerHTML = `Total ${totalAll} Kursi &middot; ${filledAll} Terisi`;

    const reduce = prefersReducedMotion();

    chartEl.innerHTML = state.liveQuotaStats
      .map((q) => {
        const scale = Math.min(1, Math.max(0.05, q.filled / q.total)).toFixed(3);
        const remaining = Math.max(0, q.total - q.filled);
        return `
        <div class="sub-surface p-4 space-y-2 text-xs">
          <div class="flex items-center justify-between gap-2">
            <div>
              <strong class="text-ink-primary block">${esc(q.label)}</strong>
              <span class="text-xs text-ink-muted">${esc(q.rombel)}</span>
            </div>
            <div class="text-right">
              <span class="font-mono font-semibold text-ink-primary block">${q.filled} / ${q.total} Kursi</span>
              <span class="text-xs text-accent-brand font-medium">Tersedia ${remaining} Kursi</span>
            </div>
          </div>
          <div class="quota-bar-track" role="progressbar" aria-label="Keterisian kuota ${esc(q.label)}" aria-valuenow="${q.filled}" aria-valuemin="0" aria-valuemax="${q.total}">
            <div class="quota-bar-fill" data-target-scale="${scale}" style="transform: scaleX(${reduce ? scale : 0});"></div>
          </div>
        </div>
      `;
      })
      .join('');

    quotaAnimated = reduce;
    animateQuotaBars();
  }

  // =====================================================================
  // D.1 AUTO-SYNC LIVE KUOTA DARI GOOGLE SHEETS DASHBOARD / DATABASE
  // =====================================================================
  function loadGoogleSheetsJsonp(sheetName) {
    const SPREADSHEET_ID = '1GzdjUBtnrKXPgZvCebYhQ6iAU0jkhgFNKDWeN6wzMa4';
    const callbackName = 'gvizCallback_' + Math.random().toString(36).substring(2, 9);
    const sheetParam = sheetName ? `&sheet=${encodeURIComponent(sheetName)}` : '';
    const url = `https://docs.google.com/spreadsheets/d/${SPREADSHEET_ID}/gviz/tq?tqx=responseHandler:${callbackName}${sheetParam}&t=${Date.now()}`;

    // Fallback untuk lingkungan non-browser (misalnya pengujian Node.js)
    if (typeof window === 'undefined' || typeof document === 'undefined' || !document.createElement) {
      return fetch(url.replace(`tqx=responseHandler:${callbackName}`, 'tqx=out:json'))
        .then((r) => r.text())
        .then((txt) => {
          const match = txt.match(/setResponse\(([\s\S]+)\);/);
          if (match) return JSON.parse(match[1]);
          throw new Error('Gviz parse error');
        });
    }

    return new Promise((resolve, reject) => {
      let resolved = false;
      const script = document.createElement('script');

      const cleanup = () => {
        try {
          delete window[callbackName];
          if (script.parentNode) script.parentNode.removeChild(script);
        } catch (_) {}
      };

      const timer = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          cleanup();
          reject(new Error('JSONP Timeout'));
        }
      }, 7000);

      window[callbackName] = (data) => {
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          cleanup();
          resolve(data);
        }
      };

      script.src = url;
      script.async = true;
      script.onerror = () => {
        if (!resolved) {
          resolved = true;
          clearTimeout(timer);
          cleanup();
          reject(new Error('Script load error'));
        }
      };

      document.head.appendChild(script);
    });
  }

  async function syncLiveQuotaFromSheets() {
    const refreshIcon = document.getElementById('refresh-quota-icon');
    if (refreshIcon) refreshIcon.classList.add('animate-spin');

    try {
      let parsedSuccessfully = false;
      const liveCounts = { PG: 0, TK: 0, SD: 0, SMP: 0, SMA: 0 };

      // 1. Prioritas Utama: Tarik langsung respon pendaftar dari sheet Form Responses 1 (Data Acuan Utama)
      try {
        const formData = await loadGoogleSheetsJsonp('Form Responses 1');
        if (formData && formData.table && Array.isArray(formData.table.rows)) {
          formData.table.rows.forEach((r) => {
            if (!r || !r.c) return;
            const nama = (r.c[1]?.v || '').toString().trim();
            const rawJenjang = (r.c[2]?.v || '').toString().trim().toUpperCase();
            if (!nama || !rawJenjang) return;

            let code = null;
            if (rawJenjang === 'PG' || rawJenjang.includes('PLAYGROUP')) code = 'PG';
            else if (rawJenjang === 'TK' || rawJenjang.includes('TK')) code = 'TK';
            else if (rawJenjang === 'SD' || rawJenjang.includes('SD')) code = 'SD';
            else if (rawJenjang === 'SMP' || rawJenjang.includes('SMP')) code = 'SMP';
            else if (rawJenjang === 'SMA' || rawJenjang.includes('SMA')) code = 'SMA';

            if (code && liveCounts[code] !== undefined) {
              liveCounts[code]++;
              parsedSuccessfully = true;
            }
          });
        }
      } catch (formErr) {
        console.warn('[PPDB Quota] Form Responses JSONP gagal, beralih ke Dashboard:', formErr && formErr.message);
      }

      // 2. Fallback: Jika tab respon form belum terbaca, baca dari 3_Dashboard_Kuota
      if (!parsedSuccessfully) {
        try {
          const dashData = await loadGoogleSheetsJsonp('3_Dashboard_Kuota');
          if (dashData && dashData.table && Array.isArray(dashData.table.rows)) {
            dashData.table.rows.forEach((r) => {
              if (!r || !r.c) return;
              const code = (r.c[0]?.v || '').toString().toUpperCase().trim();
              const filledVal = parseInt(r.c[3]?.v || r.c[3]?.f || '0', 10);
              if (['PG', 'TK', 'SD', 'SMP', 'SMA'].includes(code) && !isNaN(filledVal)) {
                liveCounts[code] = filledVal;
                parsedSuccessfully = true;
              }
            });
          }
        } catch (dashErr) {
          console.warn('[PPDB Quota] Dashboard tab JSONP gagal:', dashErr && dashErr.message);
        }
      }

      if (parsedSuccessfully) {
        state.liveQuotaStats.forEach((stat) => {
          if (liveCounts[stat.code] !== undefined) {
            stat.filled = liveCounts[stat.code];
          }
        });
      }

      renderLiveQuotaChart();
      animateQuotaBars(true);

      const totalAll = state.liveQuotaStats.reduce((s, q) => s + q.total, 0);
      const filledAll = state.liveQuotaStats.reduce((s, q) => s + q.filled, 0);
      const remainingAll = Math.max(0, totalAll - filledAll);

      const elBadge = document.getElementById('quota-badge-summary');
      if (elBadge) {
        elBadge.innerHTML = `Total ${totalAll} Kursi &middot; ${filledAll} Terisi`;
      }
      const elFilled = document.getElementById('quota-summary-filled');
      if (elFilled) {
        elFilled.textContent = `${filledAll} Siswa`;
      }
      const elRemaining = document.getElementById('quota-summary-remaining');
      if (elRemaining) {
        elRemaining.textContent = `${remainingAll} Kursi`;
      }
    } catch (err) {
      console.warn('[PPDB Quota Realtime Sync] Menggunakan data lokal:', err && err.message ? err.message : err);
    } finally {
      if (refreshIcon) {
        setTimeout(() => refreshIcon.classList.remove('animate-spin'), 600);
      }
    }
  }

  window.syncLiveQuotaFromSheets = syncLiveQuotaFromSheets;

  function renderPPDB() {
    if (!KB || !KB.biaya) return;
    const tbody = document.getElementById('fee-master-tbody');
    if (tbody) {
      const units = KB.biaya.units || [];
      if (!units.length) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center text-ink-secondary py-6">Tabel biaya pendidikan belum tersedia.</td></tr>`;
      } else {
        tbody.innerHTML = units
          .map(
            (u, idx) => `
          <tr class="reveal-row" style="--stagger-delay: ${idx * 55}ms;">
            <td class="font-semibold text-ink-primary">${esc(u.nama)}</td>
            <td class="text-right font-mono text-ink-secondary">${R(u.formulir)}</td>
            <td class="text-right font-mono font-semibold text-ink-primary">${R(u.dpp)}</td>
            <td class="text-right font-mono text-ink-secondary">${R(u.paket)}</td>
            <td class="text-right font-mono text-ink-secondary">${R(u.spp)}</td>
            <td class="text-right font-mono font-bold text-accent-brand">${R(u.awalMasuk)}</td>
          </tr>
        `
          )
          .join('');
        observeReveals(tbody);
      }
    }

    renderLiveQuotaChart();
  }

  // =====================================================================
  // E. KONSULTASI & LAYANAN INFORMASI (Chatbot Minimalis & FAQ Akordeon)
  // =====================================================================
  function appendChatBubble(role, markdownText, options = {}) {
    const stream = document.getElementById('chat-messages');
    if (!stream) return null;
    const isUser = role === 'user';
    const isError = Boolean(options.isError);
    const wrap = document.createElement('div');
    wrap.className = `chat-msg-enter flex items-start gap-3 ${isUser ? 'flex-row-reverse' : ''}`;
    const bubbleClass = isUser
      ? 'chat-bubble-user px-4 py-3 text-xs leading-relaxed'
      : isError
      ? 'chat-bubble-err px-4 py-3 text-xs leading-relaxed'
      : 'chat-bubble-bot px-4 py-3 text-xs chat-md leading-relaxed';

    wrap.innerHTML = `
      <div class="w-8 h-8 rounded-full ${
        isUser ? 'bg-[var(--btn-primary-bg)] text-[var(--btn-primary-text)]' : 'chat-avatar-bot'
      } flex items-center justify-center shrink-0 mt-0.5 text-xs">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${
          isUser
            ? '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle>'
            : '<path d="M3 18v-6a9 9 0 0 1 18 0v6"></path><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"></path>'
        }</svg>
      </div>
      <div class="max-w-[82%] min-w-0 ${bubbleClass}">
        ${isUser ? esc(markdownText) : renderMarkdown(markdownText)}
      </div>
    `;
    stream.appendChild(wrap);
    stream.scrollTop = stream.scrollHeight;
    return wrap;
  }

  function resetChat() {
    state.chatHistory = [];
    const stream = document.getElementById('chat-messages');
    if (!stream) return;
    stream.innerHTML = '';
    appendChatBubble(
      'assistant',
      `Assalamu'alaikum Warahmatullahi Wabarakatuh, Bapak/Ibu.\n\nSelamat datang di Layanan Konsultasi Resmi **Yayasan Pendidikan Islam Al-Mun'imiyah**. Saya **Ustadzah Fatimah**, siap membantu menjawab pertanyaan seputar pendaftaran siswa baru, rincian biaya pendidikan, ketentuan beasiswa Statuta Pasal 9, kurikulum tahfidz, maupun nomor rekening Virtual Account resmi.`
    );
  }

  async function sendChatPrompt(promptText) {
    const msg = String(promptText || '').trim();
    if (!msg) return;

    appendChatBubble('user', msg);
    const inputEl = document.getElementById('chat-input');
    const submitBtn = document.getElementById('chat-submit');
    const submitTextEl = submitBtn ? submitBtn.querySelector('.chat-btn-text') : null;
    if (inputEl) inputEl.value = '';
    if (submitBtn) {
      submitBtn.disabled = true;
      if (submitTextEl) submitTextEl.textContent = 'Mengirim...';
      else submitBtn.textContent = 'Mengirim...';
    }

    const loadingBubble = appendChatBubble('assistant', 'Sedang memeriksa rujukan resmi yayasan...');

    try {
      if (!KB) throw new Error('Basis pengetahuan belum siap.');
      let data;
      try {
        const res = await fetch('./api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: msg, history: state.chatHistory }),
        });
        if (!res.ok) throw new Error('Static');
        data = await res.json();
      } catch {
        data = window.YPIAAssistant.localAnswer(KB, msg, state.chatHistory);
      }
      if (loadingBubble) loadingBubble.remove();
      const reply = data.reply || 'Mohon maaf, terjadi kendala teknis pada layanan konsultasi.';
      state.chatHistory.push({ role: 'user', content: msg }, { role: 'assistant', content: reply });
      appendChatBubble('assistant', reply);
    } catch {
      if (loadingBubble) loadingBubble.remove();
      appendChatBubble(
        'assistant',
        'Maaf, layanan konsultasi gagal memproses pesan karena data basis pengetahuan belum termuat. Silakan muat ulang halaman ini.',
        { isError: true }
      );
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        if (submitTextEl) submitTextEl.textContent = 'Kirim Pesan';
        else submitBtn.textContent = 'Kirim Pesan';
      }
    }
  }

  function renderFAQ(cascade = false) {
    const listEl = document.getElementById('faq-items-list');
    if (!KB || !KB.faq) {
      if (listEl) listEl.innerHTML = `<div class="text-xs text-ink-secondary py-6 text-center">Daftar pertanyaan umum belum tersedia.</div>`;
      return;
    }

    const allowedCodes = ['A', 'B', 'C', 'D'];
    const catTitles = {
      A: 'Umum & Legalitas',
      B: 'Kurikulum & Tahfidz',
      C: 'Teknis PPDB',
      D: 'Biaya & VA Resmi',
    };
    const filteredCategories = KB.faq.categories.filter((c) => allowedCodes.includes(c.code));
    const cats = [
      { code: 'ALL', label: 'Semua Topik' },
      ...filteredCategories.map((c) => ({ code: c.code, label: catTitles[c.code] || `Kategori ${c.code}` })),
    ];

    const tabWrap = document.getElementById('faq-cat-tabs');
    if (tabWrap) {
      tabWrap._pillRecreated = true;
      tabWrap.classList.add('has-sliding-pill');
      tabWrap.innerHTML =
        '<span class="tab-sliding-indicator" aria-hidden="true"></span>' +
        cats
          .map(
            (c) => `
        <button type="button" data-faq-cat="${esc(c.code)}" aria-pressed="${state.faqCategory === c.code}" class="tab-btn ${
              state.faqCategory === c.code ? 'is-active' : ''
            }">
          ${esc(c.label)}
        </button>
      `
          )
          .join('');

      const activeFaqBtn = tabWrap.querySelector('[data-faq-cat][aria-pressed="true"]');
      if (activeFaqBtn) syncSlidingPill(tabWrap, activeFaqBtn, '.tab-sliding-indicator');

      tabWrap.querySelectorAll('[data-faq-cat]').forEach((b) => {
        b.addEventListener('click', () => {
          state.faqCategory = b.getAttribute('data-faq-cat');
          renderFAQ(true);
        });
      });
    }

    const q = state.faqQuery.toLowerCase().trim();
    const items = [];
    for (const cat of filteredCategories) {
      if (state.faqCategory !== 'ALL' && state.faqCategory !== cat.code) continue;
      for (const it of cat.items) {
        if (q && !`${it.q} ${it.a}`.toLowerCase().includes(q)) continue;
        items.push({ ...it, catLabel: catTitles[cat.code] || `Kategori ${cat.code}` });
      }
    }

    if (!listEl) return;
    if (!items.length) {
      listEl.innerHTML = `
        <div class="sub-surface p-5 text-center space-y-3 text-xs faq-cascade">
          <p class="text-ink-secondary">Tidak ada pertanyaan yang sesuai dengan kata kunci pencarian Anda.</p>
          <button type="button" id="btn-reset-faq" class="btn-secondary !py-1.5 !px-3.5 !text-xs">Tampilkan Semua Pertanyaan</button>
        </div>
      `;
      const resetFaqBtn = document.getElementById('btn-reset-faq');
      if (resetFaqBtn) {
        resetFaqBtn.addEventListener('click', () => {
          state.faqQuery = '';
          state.faqCategory = 'ALL';
          const faqSearchEl = document.getElementById('faq-search');
          if (faqSearchEl) faqSearchEl.value = '';
          renderFAQ(true);
        });
      }
      return;
    }

    const useCascade = cascade && !prefersReducedMotion();
    listEl.innerHTML = items
      .map(
        (it, idx) => `
      <details class="faq-detail text-xs ${useCascade ? 'faq-cascade' : ''}" style="--faq-delay: ${Math.min(idx, 6) * 32}ms;">
        <summary class="font-semibold text-ink-primary cursor-pointer list-none flex items-center justify-between gap-3">
          <span class="leading-relaxed">${esc(it.q)}</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="faq-chevron text-ink-muted shrink-0" aria-hidden="true">
            <polyline points="6 9 12 15 18 9"></polyline>
          </svg>
        </summary>
        <p class="faq-answer text-ink-secondary leading-relaxed mt-3 pt-3">${esc(it.a)}</p>
      </details>
    `
      )
      .join('');
  }

  function renderKonsultasi() {
    resetChat();
    renderFAQ(false);
  }

  // =====================================================================
  // MODAL ARSIP RESMI YAYASAN (MURNI 5 BERKAS MASTER)
  // =====================================================================
  function renderDriveModal() {
    const masterDocs = getMasterDocsWithUrls();
    const folderLink = document.getElementById('drive-folder-link');
    if (folderLink) {
      folderLink.href = 'https://drive.google.com/drive/folders/157nEr-14sON96VUaWsNkkpetWrMI_bQs';
    }
    const listEl = document.getElementById('drive-files-list');
    if (!listEl) return;
    listEl.innerHTML = masterDocs
      .map(
        (d, idx) => `
      <div class="modal-doc-item sub-surface sub-surface-interactive p-4 flex items-center justify-between gap-4" style="--doc-delay: ${idx * 48}ms;">
        <div>
          <div class="font-semibold text-ink-primary text-sm">${esc(d.title)}</div>
          <div class="text-xs text-ink-secondary mt-0.5">${esc(d.subtitle)}</div>
        </div>
        <a href="${esc(d.url)}" target="_blank" rel="noopener" class="btn-secondary !py-1.5 !px-3.5 !text-xs shrink-0" aria-label="Buka ${esc(d.title)} di tab baru">
          <span>Buka</span>
        </a>
      </div>
    `
      )
      .join('');
  }

  // =====================================================================
  // ERROR STATE HANDLER (R-27)
  // =====================================================================
  function renderErrorState(message) {
    const errorHtml = `
      <div class="error-card space-y-3 md:col-span-2 lg:col-span-3" role="alert">
        <p class="text-sm font-semibold">Gagal Memuat Data Resmi Lembaga</p>
        <p class="text-xs">${esc(message)}</p>
        <button type="button" data-retry-init class="btn-secondary !text-xs">Muat Ulang Data</button>
      </div>
    `;
    const profilGrid = document.getElementById('profil-struktur-grid');
    const unitGrid = document.getElementById('unit-cards-grid');
    const faqList = document.getElementById('faq-items-list');
    const feeBody = document.getElementById('fee-master-tbody');

    if (profilGrid) profilGrid.innerHTML = errorHtml;
    if (unitGrid) unitGrid.innerHTML = errorHtml;
    if (faqList) faqList.innerHTML = errorHtml;
    if (feeBody) feeBody.innerHTML = `<tr><td colspan="6" class="text-center text-ink-secondary py-6">Gagal memuat rincian biaya. Silakan muat ulang halaman.</td></tr>`;

    document.querySelectorAll('[data-retry-init]').forEach((btn) => {
      btn.addEventListener('click', init);
    });
  }

  // =====================================================================
  // DIALOG FOCUS TRAP & KEYBOARD EVENTS (R-32)
  // =====================================================================
  function openDriveModal() {
    const modal = document.getElementById('drive-modal');
    if (!modal) return;
    const openBtn = document.getElementById('btn-drive-status');
    lastFocusedEl = document.activeElement && document.activeElement !== document.body ? document.activeElement : openBtn;
    modal.classList.remove('hidden');
    const closeBtn = document.getElementById('btn-close-drive-modal');
    if (closeBtn) closeBtn.focus();
  }

  function closeDriveModal() {
    const modal = document.getElementById('drive-modal');
    if (!modal || modal.classList.contains('hidden')) return;
    modal.classList.add('hidden');
    if (lastFocusedEl && typeof lastFocusedEl.focus === 'function') {
      lastFocusedEl.focus();
    }
  }

  function setupEvents() {
    initThemeToggle();
    bindCardSpotlights();
    observeReveals();
    initScrollEngine();

    const chatForm = document.getElementById('chat-form');
    if (chatForm) {
      chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const inputEl = document.getElementById('chat-input');
        if (inputEl) sendChatPrompt(inputEl.value);
      });
    }

    const clearBtn = document.getElementById('btn-clear-chat');
    if (clearBtn) clearBtn.addEventListener('click', resetChat);

    const faqSearch = document.getElementById('faq-search');
    if (faqSearch) {
      faqSearch.addEventListener('input', (e) => {
        state.faqQuery = e.target.value;
        renderFAQ();
      });
    }

    const modal = document.getElementById('drive-modal');
    const openModalBtn = document.getElementById('btn-drive-status');
    const closeModalBtn = document.getElementById('btn-close-drive-modal');
    if (openModalBtn) openModalBtn.addEventListener('click', openDriveModal);
    if (closeModalBtn) closeModalBtn.addEventListener('click', closeDriveModal);
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) closeDriveModal();
      });
      document.addEventListener('keydown', (e) => {
        if (modal.classList.contains('hidden')) return;
        if (e.key === 'Escape') {
          closeDriveModal();
          return;
        }
        if (e.key === 'Tab') {
          const focusables = modal.querySelectorAll('a[href], button:not(:disabled), [tabindex]:not([tabindex="-1"])');
          if (!focusables.length) return;
          const first = focusables[0];
          const last = focusables[focusables.length - 1];
          if (e.shiftKey && document.activeElement === first) {
            e.preventDefault();
            last.focus();
          } else if (!e.shiftKey && document.activeElement === last) {
            e.preventDefault();
            first.focus();
          }
        }
      });
    }

    const mobileMenu = document.getElementById('mobile-menu');
    const mobileBtn = document.getElementById('btn-mobile-menu');
    if (mobileBtn && mobileMenu) {
      const setMenuOpen = (open) => {
        mobileMenu.classList.toggle('hidden', !open);
        mobileBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      };
      mobileBtn.addEventListener('click', () => {
        const isClosed = mobileMenu.classList.contains('hidden');
        setMenuOpen(isClosed);
      });
      mobileMenu.querySelectorAll('a').forEach((a) => {
        a.addEventListener('click', () => setMenuOpen(false));
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !mobileMenu.classList.contains('hidden')) {
          setMenuOpen(false);
          mobileBtn.focus();
        }
      });
    }

    // PPDB Online Form Radio Cards Selection State
    const ppdbForm = document.getElementById('ppdb-online-form');
    if (ppdbForm) {
      ppdbForm.addEventListener('change', (e) => {
        if (e.target && e.target.type === 'radio') {
          const radioName = e.target.name;
          const groupRadios = ppdbForm.querySelectorAll(`input[type="radio"][name="${radioName}"]`);
          groupRadios.forEach((r) => {
            const card = r.closest('.form-radio-card');
            if (card) {
              if (r.checked) {
                card.classList.add('is-selected');
              } else {
                card.classList.remove('is-selected');
              }
            }
          });
        }
      });

      // PPDB Form Submission Handler (Direct Fetch Multi-Page Protocol + Fallback)
      ppdbForm.addEventListener('submit', (e) => {
        if (e && e.preventDefault) e.preventDefault();

        const submitBtn = document.getElementById('btn-submit-ppdb');
        const submitText = document.getElementById('btn-submit-ppdb-text');
        if (submitBtn) submitBtn.disabled = true;
        if (submitText) submitText.textContent = 'Mengirim Data Pendaftaran...';

        const studentName = document.getElementById('ppdb-student-name')?.value?.trim() || '';
        const unitRadio = ppdbForm.querySelector('input[name="entry.886746899"]:checked')?.value || 'SD';
        const waveRadio = ppdbForm.querySelector('input[name="entry.1502592928"]:checked')?.value || 'Gelombang 1';
        const discountCat = document.getElementById('ppdb-discount-cat')?.value || 'Reguler / Umum';
        const tahfidzCat = document.getElementById('ppdb-tahfidz-cat')?.value || 'Tidak Ada';
        const paymentRadio = ppdbForm.querySelector('input[name="entry.1676886351"]:checked')?.value || 'LUNAS';
        const parentName = document.getElementById('ppdb-parent-name')?.value?.trim() || '';
        const parentPhone = document.getElementById('ppdb-parent-phone')?.value?.trim() || '';

        // Hitung estimasi nomor registrasi, VA BSI, biaya formulir, dan total tagihan resmi
        const currentFilled = state.liveQuotaStats.reduce((s, q) => s + (q.filled || 0), 0) || 22;
        const seqNumber = currentFilled + 1;
        const seqStr = String(seqNumber).padStart(4, '0');
        const unitCodes = { PG: '1', TK: '2', SD: '3', SMP: '4', SMA: '5' };
        const unitCode = unitCodes[unitRadio] || '3';
        const regNumber = `YPIA-26-${unitRadio}-${seqStr}`;
        const vaNumber = `900120${unitCode}${seqStr}`;

        // Rincian Tarif & Diskon Resmi PPDB YPIA
        const formFees = { PG: 250000, TK: 250000, SD: 350000, SMP: 400000, SMA: 450000 };
        const dppNormals = { PG: 5500000, TK: 7500000, SD: 14500000, SMP: 17500000, SMA: 20000000 };
        const otherFees = { PG: 3950000, TK: 4550000, SD: 6650000, SMP: 7450000, SMA: 8100000 };

        const formFee = formFees[unitRadio] || 350000;
        const dppNormal = dppNormals[unitRadio] || 14500000;
        const otherFee = otherFees[unitRadio] || 6650000;

        let waveDiscPct = 0;
        if (waveRadio === 'Gelombang 1') waveDiscPct = 0.15;
        else if (waveRadio === 'Gelombang 2') waveDiscPct = 0.08;

        let statutaDiscPct = 0;
        if (tahfidzCat.includes('10 Juz') || discountCat.includes('Afirmasi')) statutaDiscPct = 1.0;
        else if (tahfidzCat.includes('5 Juz')) statutaDiscPct = 0.5;
        else if (discountCat.includes('Alumni')) statutaDiscPct = 0.2;
        else if (discountCat.includes('Sibling') || discountCat.includes('Saudara')) statutaDiscPct = 0.1;

        let lunasDiscPct = paymentRadio === 'LUNAS' ? 0.03 : 0.0;
        const totalDiscPct = Math.min(1.0, waveDiscPct + statutaDiscPct + lunasDiscPct);
        const dppNet = Math.round(dppNormal * (1 - totalDiscPct));
        const totalBill = dppNet + otherFee;

        const formatRp = (num) => 'Rp ' + Number(num || 0).toLocaleString('id-ID');
        const cleanPhone = (phone) => {
          let p = (phone || '').replace(/[^0-9]/g, '');
          if (p.startsWith('0')) p = '62' + p.substring(1);
          return p;
        };
        const parentPhoneClean = cleanPhone(parentPhone);

        // Tampilkan Ringkasan Faktur & Tagihan Sukses Seketika
        const successBanner = document.getElementById('ppdb-success-banner');
        const summaryEl = document.getElementById('ppdb-success-summary');
        const waParentBtn = document.getElementById('ppdb-wa-parent-btn');
        const waConfirmBtn = document.getElementById('ppdb-wa-confirm-btn');

        if (summaryEl) {
          summaryEl.innerHTML = `
            <div class="space-y-2">
              <div class="flex flex-wrap items-center justify-between border-b border-hairline pb-2 text-xs">
                <span>No. Registrasi: <strong class="text-ink-primary font-bold text-sm tracking-wide">${esc(regNumber)}</strong></span>
                <span class="text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 px-2 py-0.5 rounded text-[11px]">Terdaftar Resmi</span>
              </div>
              <div class="p-3 rounded-xl bg-zinc-100 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700/80 space-y-1">
                <div class="text-[10px] uppercase tracking-wider text-ink-muted font-sans font-bold">Nomor Virtual Account BSI Resmi:</div>
                <div class="text-base font-bold text-ink-primary font-mono tracking-wider flex items-center justify-between">
                  <span class="select-all">${esc(vaNumber)}</span>
                  <span class="text-[10px] font-sans font-normal text-ink-muted">Bank Syariah Indonesia (BSI)</span>
                </div>
              </div>
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
                <div>&bull; Biaya Formulir: <strong class="text-ink-primary">${formatRp(formFee)}</strong></div>
                <div>&bull; Est. Daftar Ulang: <strong class="text-ink-primary">${formatRp(totalBill)}</strong></div>
                <div>&bull; Calon Siswa: <strong>${esc(studentName || '-')}</strong> (${esc(unitRadio)})</div>
                <div>&bull; Orang Tua/Wali: <strong>${esc(parentName || '-')}</strong> (${esc(parentPhone || '-')})</div>
                <div>&bull; Skema: <strong>${esc(paymentRadio === 'LUNAS' ? 'Pelunasan Sekaligus (Diskon 3%)' : 'Cicilan 3x Termin')}</strong></div>
                <div>&bull; Diskon Akumulasi: <strong>${Math.round(totalDiscPct * 100)}%</strong></div>
              </div>
            </div>
          `;
        }

        // Pesan Resmi Tagihan & VA untuk dikirimkan ke WhatsApp Orang Tua
        const invoiceMsgForParent = `*INVOICE & NOMOR VIRTUAL ACCOUNT PPDB YPIA TA 2026/2027*
Yayasan Pendidikan Islam Al-Mun'imiyah

Assalamu'alaikum Warahmatullahi Wabarakatuh,
Yth. Ayah/Bunda *${parentName || 'Orang Tua / Wali'}*,
Wali dari calon siswa: *${studentName}* (Jenjang ${unitRadio})

Alhamdulillah, data pendaftaran Ananda telah berhasil dicatat resmi di Sistem Penerimaan Peserta Didik Baru (PPDB) Yayasan Pendidikan Islam Al-Mun'imiyah.

📋 *DATA REGISTRASI RESMI:*
• No. Registrasi : *${regNumber}*
• Jenjang Tujuan : *${unitRadio}*
• Gelombang      : *${waveRadio}*
• Kategori Jalur : *${discountCat}*
• Skema Bayar    : *${paymentRadio === 'LUNAS' ? 'Pelunasan Sekaligus (Diskon Ekstra 3%)' : 'Cicilan 3x Termin Resmi'}*

💳 *REKENING VIRTUAL ACCOUNT RESMI (BSI):*
• Bank Penerima  : *Bank Syariah Indonesia (BSI)*
• Nomor VA       : *${vaNumber}*
• Atas Nama      : *YPI AL-MUN'IMIYAH - ${studentName}*
• Biaya Formulir : *${formatRp(formFee)}*
• Estimasi Tagihan Daftar Ulang : *${formatRp(totalBill)}* (Diskon DPP ${Math.round(totalDiscPct * 100)}%)

📌 *PETUNJUK PEMBAYARAN:*
1. Pembayaran Biaya Formulir sebesar *${formatRp(formFee)}* dilakukan via BSI Mobile / ATM / Transfer Antarbank ke Nomor VA BSI di atas (Pilih Bank Syariah Indonesia / Kode Bank 451).
2. Simpan bukti transfer untuk validasi berkas pada saat observasi / pemetaan minat bakat siswa.
3. Hotline & Layanan Informasi Resmi YPIA: *0895-3782-33567*.

Jazakumullah Khairan Katsiran atas kepercayaan Ayah/Bunda kepada Yayasan Pendidikan Islam Al-Mun'imiyah.
Wassalamu'alaikum Warahmatullahi Wabarakatuh.
_Panitia PPDB YPIA Kota Bandung_`;

        if (waParentBtn) {
          const targetWa = parentPhoneClean || '62895378233567';
          waParentBtn.href = `https://wa.me/${targetWa}?text=${encodeURIComponent(invoiceMsgForParent)}`;
          const waParentText = document.getElementById('ppdb-wa-parent-text');
          if (waParentText) {
            waParentText.textContent = parentPhone ? `Kirim VA ke No WA Tertera (${parentPhone}) ↗` : 'Kirim VA ke No WA Tertera ↗';
          }
        }

        if (waConfirmBtn) {
          const adminWaMsg = `Assalamu'alaikum Panitia PPDB YPIA. Saya mengonfirmasi pendaftaran online siswa:
• Nama Siswa: ${studentName} (${unitRadio})
• No. Registrasi: ${regNumber}
• No. VA BSI: ${vaNumber}
• Biaya Formulir: ${formatRp(formFee)}
• Estimasi Daftar Ulang: ${formatRp(totalBill)}
• Orang Tua: ${parentName} (${parentPhone})
Mohon verifikasi nomor registrasi dan jadwal observasi Ananda. Terima kasih.`;
          waConfirmBtn.href = `https://wa.me/62895378233567?text=${encodeURIComponent(adminWaMsg)}`;
        }

        if (successBanner) {
          successBanner.classList.remove('hidden');
          successBanner.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }

        // Siapkan payload form data lengkap (mengirim langsung via fetch no-cors yang kebal batasan iframe)
        const params = new URLSearchParams();
        params.append('fvv', '1');
        params.append('pageHistory', '0,1');
        params.append('entry.8597841', studentName);
        params.append('entry.886746899', unitRadio);
        params.append('entry.1502592928', waveRadio);
        params.append('entry.1880708247', discountCat);
        params.append('entry.447849860', tahfidzCat);
        params.append('entry.1676886351', paymentRadio);
        params.append('entry.2102236790', parentName);
        params.append('entry.1381684453', parentPhone);

        const formActionUrl = ppdbForm.getAttribute('action') || 'https://docs.google.com/forms/d/e/1FAIpQLSeYFTTWE3y8D9O_Q3IXDNZ6x7QxFB_02IMNyntsuNkB8jAoHA/formResponse';

        // Eksekusi pengiriman data langsung ke Google Forms
        fetch(formActionUrl, {
          method: 'POST',
          mode: 'no-cors',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: params.toString()
        }).then(() => {
          console.log('[PPDB Form] Berhasil dikirimkan ke Google Forms via Direct Fetch');
        }).catch((err) => {
          console.warn('[PPDB Form] Direct fetch gagal, mencoba fallback iframe:', err);
          try {
            ppdbForm.submit();
          } catch (_) {}
        }).finally(() => {
          if (submitBtn) submitBtn.disabled = false;
          if (submitText) submitText.textContent = 'Kirim Formulir Pendaftaran Sekarang';

          // Sinkronisasi kuota realtime beberapa detik setelah pendaftaran masuk
          setTimeout(() => syncLiveQuotaFromSheets(), 1500);
          setTimeout(() => syncLiveQuotaFromSheets(), 4000);
          setTimeout(() => syncLiveQuotaFromSheets(), 7500);
        });

        // Form reset ditunda 4 detik agar tidak mengosongkan input sebelum dikirim
        setTimeout(() => {
          ppdbForm.reset();
          const sdCard = ppdbForm.querySelector('input[value="SD"]')?.closest('.form-radio-card');
          const g1Card = ppdbForm.querySelector('input[value="Gelombang 1"]')?.closest('.form-radio-card');
          const lunasCard = ppdbForm.querySelector('input[value="LUNAS"]')?.closest('.form-radio-card');
          ppdbForm.querySelectorAll('.form-radio-card').forEach((c) => c.classList.remove('is-selected'));
          if (sdCard) sdCard.classList.add('is-selected');
          if (g1Card) g1Card.classList.add('is-selected');
          if (lunasCard) lunasCard.classList.add('is-selected');
        }, 4000);
      });
    }

    // Tombol Manual Refresh Kuota Realtime
    const refreshQuotaBtn = document.getElementById('btn-refresh-quota');
    if (refreshQuotaBtn) {
      refreshQuotaBtn.addEventListener('click', () => {
        syncLiveQuotaFromSheets();
      });
    }

    // Polling kuota berkala (setiap 25 detik) saat tab browser aktif
    setInterval(() => {
      if (document.visibilityState === 'visible') {
        syncLiveQuotaFromSheets();
      }
    }, 25000);

    // Refresh realtime saat pengguna kembali ke tab browser
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        syncLiveQuotaFromSheets();
      }
    });

    const resetBannerBtn = document.getElementById('btn-reset-ppdb-banner');
    if (resetBannerBtn) {
      resetBannerBtn.addEventListener('click', () => {
        const successBanner = document.getElementById('ppdb-success-banner');
        if (successBanner) successBanner.classList.add('hidden');
      });
    }

    // Toggle Google Forms Fallback Frame
    const toggleFrameBtn = document.getElementById('btn-toggle-google-frame');
    const fallbackWrapper = document.getElementById('google-forms-fallback-wrapper');
    const googleIframe = document.getElementById('google-forms-iframe-el');
    if (toggleFrameBtn && fallbackWrapper) {
      toggleFrameBtn.addEventListener('click', () => {
        const isHidden = fallbackWrapper.classList.toggle('hidden');
        if (!isHidden && googleIframe && (!googleIframe.src || googleIframe.src === 'about:blank')) {
          googleIframe.src = googleIframe.dataset.src || '';
        }
        toggleFrameBtn.textContent = isHidden
          ? 'Lihat Tampilan Google Forms Asli ↗'
          : 'Sembunyikan Google Forms Asli ↖';
      });
    }

    // Auto-hide Floating FAB saat berada di area Konsultasi agar tidak menutupi tombol Kirim Pesan
    const chatSection = document.getElementById('konsultasi');
    const floatingFab = document.getElementById('floating-chatbot-widget');
    if (chatSection && floatingFab && 'IntersectionObserver' in window) {
      const chatFabObserver = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              floatingFab.classList.add('fab-hidden-on-chat');
            } else {
              floatingFab.classList.remove('fab-hidden-on-chat');
            }
          });
        },
        { threshold: 0.1 }
      );
      chatFabObserver.observe(chatSection);
    }
  }

  let eventsBound = false;
  async function init() {
    console.log('[APP] init() started');
    if (!eventsBound) {
      setupEvents();
      eventsBound = true;
      console.log('[APP] setupEvents() finished');
    }
    try {
      try {
        const res = await fetch('./api/kb');
        if (!res.ok) throw new Error('HTTP ' + res.status);
        KB = await res.json();
      } catch {
        const res = await fetch('./data/kb.json');
        if (!res.ok) throw new Error('HTTP ' + res.status);
        KB = await res.json();
      }
      console.log('[APP] KB loaded, rendering sections...');
      renderBeranda();
      console.log('[APP] renderBeranda done');
      renderProfil();
      console.log('[APP] renderProfil done');
      renderUnit();
      console.log('[APP] renderUnit done');
      renderPPDB();
      console.log('[APP] renderPPDB done');
      renderKonsultasi();
      console.log('[APP] renderKonsultasi done');
      renderDriveModal();
      console.log('[APP] renderDriveModal done');
      bindCardSpotlights();
      observeReveals();
      window.requestAnimationFrame(() => {
        updateOverlapChoreography();
        flushVisibleReveals();
        animateQuotaBars();
      });

      // Live Auto-Sync Kuota PPDB dari Google Sheets
      await syncLiveQuotaFromSheets();
      console.log('[APP] syncLiveQuotaFromSheets done');
    } catch (err) {
      console.error('[APP] init error:', err);
      renderErrorState(err && err.message ? err.message : 'Koneksi ke berkas data gagal.');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
