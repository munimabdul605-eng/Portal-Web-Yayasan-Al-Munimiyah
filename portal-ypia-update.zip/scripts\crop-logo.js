const fs = require('fs');
const zlib = require('zlib');

const srcPath = 'C:/Users/LENOVO/.gemini/antigravity/brain/9df9d019-89af-48ce-906c-ab9ba638ff0d/.user_uploaded/media_1794129019653_12967187.png';
const destPath = 'public/assets/logo-ypia-transparent.png';

const buf = fs.readFileSync(srcPath);

let idatChunks = [];
let offset = 8;
while (offset < buf.length) {
  const len = buf.readUInt32BE(offset);
  const type = buf.slice(offset + 4, offset + 8).toString('ascii');
  if (type === 'IDAT') idatChunks.push(buf.slice(offset + 8, offset + 8 + len));
  offset += 12 + len;
}
const decompressed = zlib.inflateSync(Buffer.concat(idatChunks));

const origW = 1024;
const origH = 1024;
const origStride = 1 + origW * 4;

// Unfilter all rows
const rawPixels = Buffer.alloc(origW * origH * 4);
let prevRow = Buffer.alloc(origW * 4);

for (let y = 0; y < origH; y++) {
  const filter = decompressed[y * origStride];
  const row = Buffer.alloc(origW * 4);
  for (let x = 0; x < origW * 4; x++) {
    const raw = decompressed[y * origStride + 1 + x];
    const a = x >= 4 ? row[x - 4] : 0;
    const b = prevRow[x];
    const c = x >= 4 ? prevRow[x - 4] : 0;
    let val = 0;
    if (filter === 0) val = raw;
    else if (filter === 1) val = (raw + a) & 0xff;
    else if (filter === 2) val = (raw + b) & 0xff;
    else if (filter === 3) val = (raw + Math.floor((a + b) / 2)) & 0xff;
    else if (filter === 4) {
      const p = a + b - c;
      const pa = Math.abs(p - a);
      const pb = Math.abs(p - b);
      const pc = Math.abs(p - c);
      let pr = c;
      if (pa <= pb && pa <= pc) pr = a;
      else if (pb <= pc) pr = b;
      val = (raw + pr) & 0xff;
    }
    row[x] = val;
  }
  prevRow = row;
  row.copy(rawPixels, y * origW * 4);
}

// Bounding box was: minX: 323, maxX: 701, minY: 261, maxY: 877
// Let's add 20px padding
const pad = 20;
const cropX = Math.max(0, 323 - pad);
const cropY = Math.max(0, 261 - pad);
const cropMaxX = Math.min(origW - 1, 701 + pad);
const cropMaxY = Math.min(origH - 1, 877 + pad);

const cropW = cropMaxX - cropX + 1;
const cropH = cropMaxY - cropY + 1;

console.log('Cropping to:', { cropX, cropY, cropW, cropH });

// Build new filtered PNG buffer (filter type 0 for simplicity)
const newStride = 1 + cropW * 4;
const newDecompressed = Buffer.alloc(cropH * newStride);

for (let cy = 0; cy < cropH; cy++) {
  const srcY = cropY + cy;
  newDecompressed[cy * newStride] = 0; // filter 0
  for (let cx = 0; cx < cropW; cx++) {
    const srcX = cropX + cx;
    const srcIdx = (srcY * origW + srcX) * 4;
    const dstIdx = cy * newStride + 1 + cx * 4;
    newDecompressed[dstIdx] = rawPixels[srcIdx];         // R
    newDecompressed[dstIdx + 1] = rawPixels[srcIdx + 1]; // G
    newDecompressed[dstIdx + 2] = rawPixels[srcIdx + 2]; // B
    newDecompressed[dstIdx + 3] = rawPixels[srcIdx + 3]; // A
  }
}

const compressedIdat = zlib.deflateSync(newDecompressed);

// Construct minimal valid PNG
// CRC32 implementation
const crcTable = [];
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c >>> 0;
}
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const len = data.length;
  const chunk = Buffer.alloc(12 + len);
  chunk.writeUInt32BE(len, 0);
  chunk.write(type, 4, 4, 'ascii');
  data.copy(chunk, 8);
  const typeAndData = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = crc32(typeAndData);
  chunk.writeUInt32BE(crc, 8 + len);
  return chunk;
}

const pngSig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

// IHDR
const ihdrData = Buffer.alloc(13);
ihdrData.writeUInt32BE(cropW, 0);
ihdrData.writeUInt32BE(cropH, 4);
ihdrData[8] = 8; // bit depth
ihdrData[9] = 6; // RGBA
ihdrData[10] = 0; // deflate
ihdrData[11] = 0; // adaptive filtering
ihdrData[12] = 0; // no interlace
const ihdrChunk = makeChunk('IHDR', ihdrData);

// IDAT
const idatChunk = makeChunk('IDAT', compressedIdat);

// IEND
const iendChunk = makeChunk('IEND', Buffer.alloc(0));

const finalPng = Buffer.concat([pngSig, ihdrChunk, idatChunk, iendChunk]);
fs.writeFileSync(destPath, finalPng);
console.log('Saved transparent cropped logo to:', destPath, 'Size:', finalPng.length, 'bytes');

