const fs = require('fs');

const files = ['public/index.html', 'public/js/app.js', 'public/css/auralis.css'];

files.forEach((file) => {
  if (!fs.existsSync(file)) return;
  const content = fs.readFileSync(file, 'utf8');
  const lines = content.split('\n');
  lines.forEach((line, idx) => {
    if (line.includes('7 7 17 7 17 17') || line.includes('x1="7"') || line.includes('x1=\'7\'')) {
      console.log(`${file}:${idx + 1}: ${line.trim()}`);
    }
    if (line.includes('btn-with-icon') && !line.includes('class=')) {
      // css rules
    }
  });
});

