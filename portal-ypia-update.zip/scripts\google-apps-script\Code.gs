/**
 * ============================================================================
 * GOOGLE APPS SCRIPT: TOMBOL KIRIM VA KE NO WA TERTERA (CARA 1 RESMI)
 * Yayasan Pendidikan Islam Al-Mun'imiyah (YPIA) Bandung
 * ============================================================================
 * 
 * Skrip ini dipasang pada Google Spreadsheet Database PPDB:
 * ID: 1GzdjUBtnrKXPgZvCebYhQ6iAU0jkhgFNKDWeN6wzMa4
 * 
 * FUNGSI UTAMA (CARA 1):
 * 1. Setiap pendaftar di baris tabel otomatis memiliki tombol/tautan di Kolom T:
 *    "📲 Kirim VA ke No WA"
 * 2. Mengarahkan langsung ke WhatsApp orang tua sesuai nomor yang tertera di Kolom I.
 * 3. Pesan invoice resmi, nomor registrasi, dan nomor VA BSI tersusun rapi otomatis.
 * 4. Zero-Cost (100% gratis, tanpa ketergantungan API pihak ketiga).
 */

const SHEET_NAME_DB = '1_Database_Pendaftar';

/**
 * Menu Khusus "🕌 PPDB YPIA" di Spreadsheet
 */
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('🕌 PPDB YPIA')
    .addItem('📲 Pasang / Perbarui Tombol WA Seluruh Pendaftar (Kolom T)', 'pasangTombolWAKolomT')
    .addItem('💬 Buka Tautan WA Baris yang Dipilih', 'bukaWABarisAktif')
    .addToUi();
}

/**
 * Rumus Formula untuk Kolom T ("Kirim_VA_ke_No_WA")
 */
function getFormulaKolomT(row) {
  const cleanPhone = `SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(TO_TEXT(I${row}),"-","")," ",""),"+",""),"'","")`;
  const normalizedPhone = `IF(LEFT(${cleanPhone},2)="62", ${cleanPhone}, IF(LEFT(${cleanPhone},1)="0", "62"&MID(${cleanPhone},2,50), IF(LEFT(${cleanPhone},1)="8", "62"&${cleanPhone}, ${cleanPhone})))`;

  const msg = `"*INVOICE & NOMOR VIRTUAL ACCOUNT (BSI) PPDB YPIA TA 2026/2027*"&CHAR(10)&CHAR(10)&` +
    `"Assalamu'alaikum Ayah/Bunda "&H${row}&", wali dari calon siswa *"&B${row}&"* ("&C${row}&")."&CHAR(10)&CHAR(10)&` +
    `"Pendaftaran Ananda telah tercatat resmi di Sistem PPDB Yayasan Pendidikan Islam Al-Mun'imiyah:"&CHAR(10)&` +
    `"• No. Registrasi : *"&J${row}&"*"&CHAR(10)&` +
    `"• No. Virtual Account BSI : *"&K${row}&"*"&CHAR(10)&` +
    `"• Biaya Formulir : *"&TEXT(L${row},"Rp#,##0")&"*"&CHAR(10)&` +
    `"• Estimasi Tagihan Daftar Ulang : *"&TEXT(S${row},"Rp#,##0")&"*"&CHAR(10)&CHAR(10)&` +
    `"Pembayaran Biaya Formulir dapat disalurkan melalui ATM/BSI Mobile/Transfer Antarbank ke Nomor VA di atas (Bank Syariah Indonesia - Kode Bank: 451, a.n YPI AL-MUN'IMIYAH - "&B${row}&")."&CHAR(10)&` +
    `"Yayasan melarang keras pembayaran tunai atau transfer ke rekening pribadi staf (Statuta Pasal 12 ayat 3)."&CHAR(10)&CHAR(10)&` +
    `"Hotline Informasi Resmi YPIA: 0895-3782-33567."&CHAR(10)&` +
    `"Jazakumullah Khairan Katsiran."`;

  return `=IF(OR(B${row}="", B${row}="Total & Rata-rata", LEFT(B${row},5)="Total"), "", HYPERLINK("https://wa.me/"&${normalizedPhone}&"?text="&ENCODEURL(${msg}), "📲 Kirim VA ke No WA"))`;
}

/**
 * Menu: Pasang / Segarkan Seluruh Tombol WA pada Kolom T (Baris 6 s.d. 100)
 */
function pasangTombolWAKolomT() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME_DB);
  if (!sheet) {
    SpreadsheetApp.getUi().alert('Sheet "' + SHEET_NAME_DB + '" tidak ditemukan.');
    return;
  }

  // Set Header di T5
  sheet.getRange('T5').setValue('Kirim_VA_ke_No_WA');

  const maxRow = Math.max(100, sheet.getLastRow());
  const formulas = [];
  for (let r = 6; r <= maxRow; r++) {
    formulas.push([getFormulaKolomT(r)]);
  }

  sheet.getRange(6, 20, formulas.length, 1).setFormulas(formulas);
  SpreadsheetApp.getUi().alert('Sukses', `Tombol "📲 Kirim VA ke No WA" berhasil dipasang pada baris 6 s.d. ${maxRow}.`, SpreadsheetApp.getUi().ButtonSet.OK);
}

/**
 * Trigger Otomatis saat Form Masuk (onFormSubmit):
 * Menjamin baris baru langsung mendapatkan tombol WA di Kolom T.
 */
function onFormSubmit(e) {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getSheetByName(SHEET_NAME_DB);
    if (!sheet) return;

    const lastRow = sheet.getLastRow();
    if (lastRow >= 6) {
      sheet.getRange(lastRow, 20).setFormula(getFormulaKolomT(lastRow));
    }
  } catch (err) {
    console.error('Error onFormSubmit:', err);
  }
}

/**
 * Menu: Buka WhatsApp langsung untuk baris yang sedang aktif dipilih kursor
 */
function bukaWABarisAktif() {
  const ui = SpreadsheetApp.getUi();
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  const row = sheet.getActiveCell().getRow();

  if (row < 6) {
    ui.alert('Perhatian', 'Silakan pilih salah satu baris data pendaftar (mulai baris 6).', ui.ButtonSet.OK);
    return;
  }

  const formula = sheet.getRange(row, 20).getFormula();
  const match = formula.match(/HYPERLINK\("([^"]+)"/);
  if (!match) {
    ui.alert('Perhatian', 'Tidak ditemukan tautan WhatsApp pada baris ini.', ui.ButtonSet.OK);
    return;
  }

  const url = match[1];
  const html = HtmlService.createHtmlOutput(
    `<p style="font-family:sans-serif;font-size:13px;">Klik tombol di bawah ini untuk membuka WhatsApp:</p>` +
    `<p><a href="${url}" target="_blank" style="display:inline-block;padding:10px 18px;background:#10b981;color:#fff;text-decoration:none;border-radius:8px;font-weight:bold;font-family:sans-serif;font-size:13px;">📲 Buka WhatsApp Sekarang</a></p>` +
    `<script>window.open("${url}", "_blank");</script>`
  ).setWidth(380).setHeight(150);

  ui.showModalDialog(html, 'Kirim VA ke WhatsApp');
}
