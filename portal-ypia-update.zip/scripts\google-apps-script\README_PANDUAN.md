# Panduan Tombol Kirim VA ke No WA Tertera (Cara 1 PPDB YPIA)

Panduan resmi penggunaan **Cara 1**: Penyediaan tombol interaktif **"📲 Kirim VA ke No WA"** untuk setiap pendaftar, baik melalui **Google Spreadsheet Database** maupun **Web Portal PPDB**.

---

## 1. Keunggulan & Prinsip Cara 1

1. **100% Zero-Cost & Bebas Biaya**:
   - Tidak memerlukan langganan bot pihak ketiga (seperti Fonnte, Wablas, atau Twilio).
   - Menggunakan tautan resmi universal WhatsApp Web & Desktop (`https://wa.me/...`).
2. **Aman & Terkendali**:
   - Panitia atau orang tua dapat meninjau rincian nomor VA dan tagihan sebelum menekan tombol kirim di WhatsApp.
   - Mengeliminasi risiko pesan terblokir atau kuota gateway habis.
3. **Format Otomatis**:
   - Nomor WhatsApp tujuan otomatis dinormalisasi ke format internasional (misal: input `0895...` atau `895...` otomatis menjadi `62895...`).
   - Nomor registrasi, Nomor VA BSI resmi, dan rincian biaya pendaftaran terisi otomatis.

---

## 2. Penggunaan di Google Spreadsheet Database

Pada tab sheet [`1_Database_Pendaftar`](https://docs.google.com/spreadsheets/d/1GzdjUBtnrKXPgZvCebYhQ6iAU0jkhgFNKDWeN6wzMa4/edit#gid=0):

1. **Lokasi Tombol**:
   - Terletak di **Kolom T** dengan header **`Kirim_VA_ke_No_WA`**.
2. **Tampilan Sel**:
   - Setiap baris pendaftar menampilkan teks tombol hijau:
     ```
     📲 Kirim VA ke No WA
     ```
3. **Cara Mengirim**:
   - Panitia cukup **mengklik** tautan pada baris pendaftar yang bersangkutan.
   - Browser akan langsung membuka WhatsApp Web / Desktop yang mengarah ke nomor WhatsApp orang tua tertera (Kolom I).
   - Pesan resmi konfirmasi, nomor registrasi, dan nomor VA BSI sudah tertulis rapi dan siap dikirim.

---

## 3. Penggunaan di Web Portal PPDB

Pada formulir web portal ([`http://localhost:3000/#ppdb`](http://localhost:3000/#ppdb)):

1. Saat orang tua menekan tombol **"Kirim Formulir Pendaftaran Sekarang"**:
   - Data langsung terkirim ke database Google Forms/Sheets.
   - Banner konfirmasi sukses langsung muncul di halaman.
2. Di dalam banner sukses terdapat tombol utama:
   ```
   [📲 Kirim VA ke No WA Tertera (08xxxxxxxxxx) ↗]
   ```
3. Mengklik tombol ini langsung membuka WhatsApp dengan nomor orang tua terdaftar sebagai penerima, berisi seluruh rincian pendaftaran dan nomor rekening Virtual Account BSI resmi.

---

## 4. (Opsional) Memasang Google Apps Script Pendukung

Jika ingin menambahkan menu Spreadsheet kustom **`🕌 PPDB YPIA`** agar panitia bisa menyegarkan seluruh formula Kolom T hanya dengan 1-klik:

1. Buka spreadsheet database: `https://docs.google.com/spreadsheets/d/1GzdjUBtnrKXPgZvCebYhQ6iAU0jkhgFNKDWeN6wzMa4/edit`
2. Klik menu **Extensions** > **Apps Script**.
3. Salin seluruh isi berkas [`Code.gs`](./Code.gs) dan simpan (`Ctrl + S`).
4. Muat ulang halaman spreadsheet (tekan F5).
5. Menu **🕌 PPDB YPIA** akan muncul di bilah atas spreadsheet dengan opsi:
   - **📲 Pasang / Perbarui Tombol WA Seluruh Pendaftar (Kolom T)**
   - **💬 Buka Tautan WA Baris yang Dipilih**
