const fs = require('fs');

async function check() {
  const res = await fetch('https://docs.google.com/forms/d/1yXFsxZxj3GBaQZ253uA516KGcuKR0bjGobmQpNedj_Y/viewform');
  const html = await res.text();
  const match = html.match(/FB_PUBLIC_LOAD_DATA_\s*=\s*(.+?);\s*<\/script>/s);
  if (!match) {
    console.log('No FB_PUBLIC_LOAD_DATA found');
    return;
  }
  const data = JSON.parse(match[1]);
  const actionMatch = html.match(/<form[^>]+action="([^"]+)"/i);
  console.log('Form Action URL:', actionMatch ? actionMatch[1] : 'not found');
  console.log('Form title:', data[1][8]);
  console.log('Form desc:', data[1][0]);
  const items = data[1][1];
  console.log('Fields count:', items.length);
  items.forEach((item, i) => {
    const title = item[1];
    const type = item[3];
    const entryId = item[4]?.[0]?.[0];
    const options = item[4]?.[0]?.[1]?.map((o) => o[0]);
    console.log(`\nField ${i + 1}: "${title}" (entry.${entryId}, type: ${type})`);
    if (options) {
      console.log('  options:', options);
    }
  });
}

check().catch(console.error);
