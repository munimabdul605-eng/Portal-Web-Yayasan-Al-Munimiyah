/**
 * Test posting to Google Forms endpoint
 */
async function testPost() {
  const formUrl = 'https://docs.google.com/forms/d/e/1FAIpQLSeYFTTWE3y8D9O_Q3IXDNZ6x7QxFB_02IMNyntsuNkB8jAoHA/formResponse';
  const params = new URLSearchParams();
  params.append('entry.8597841', 'Test Calon Siswa (Verifikasi Sistem)');
  params.append('entry.886746899', 'SD');
  params.append('entry.1502592928', 'Gelombang 1');
  params.append('entry.1880708247', 'Reguler / Umum');
  params.append('entry.447849860', 'Tidak Ada');
  params.append('entry.1676886351', 'LUNAS');
  params.append('entry.2102236790', 'Bapak Penguji');
  params.append('entry.1381684453', '081234567890');

  console.log('[TEST] Sending test submission to Google Forms...');
  const res = await fetch(formUrl, {
    method: 'POST',
    mode: 'no-cors',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body: params.toString()
  });

  console.log('[TEST] Result status:', res.status, res.statusText);
}

testPost().catch(console.error);

