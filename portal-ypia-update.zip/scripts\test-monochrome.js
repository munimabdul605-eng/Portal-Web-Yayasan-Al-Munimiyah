/**
 * test-monochrome.js
 * Inspects computed colors and glassmorphism styling in both Light and Dark mode.
 */
const http = require('http');
const { spawn } = require('child_process');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PORT = 9223;
const TARGET_URL = 'http://localhost:3000/';

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => resolve(JSON.parse(data)));
    }).on('error', reject);
  });
}

async function run() {
  const chrome = spawn(
    CHROME_PATH,
    [
      '--headless=new',
      `--remote-debugging-port=${PORT}`,
      '--disable-gpu',
      '--no-first-run',
      'about:blank',
    ],
    { stdio: 'ignore' }
  );

  let exited = false;
  chrome.on('exit', () => { exited = true; });

  try {
    let version = null;
    for (let i = 0; i < 20; i++) {
      try {
        version = await getJson(`http://127.0.0.1:${PORT}/json/version`);
        if (version && version.webSocketDebuggerUrl) break;
      } catch (e) {}
      await wait(300);
    }

    const pages = await getJson(`http://127.0.0.1:${PORT}/json/list`);
    const targetPage = pages.find((p) => p.type === 'page') || pages[0];
    const ws = new WebSocket(targetPage.webSocketDebuggerUrl);

    let msgId = 1;
    const callbacks = new Map();
    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.id && callbacks.has(msg.id)) {
        const { resolve, reject } = callbacks.get(msg.id);
        callbacks.delete(msg.id);
        if (msg.error) reject(msg.error);
        else resolve(msg.result);
      }
    };

    await new Promise((resolve) => { ws.onopen = resolve; });

    function sendCommand(method, params = {}) {
      const id = msgId++;
      return new Promise((resolve, reject) => {
        callbacks.set(id, { resolve, reject });
        ws.send(JSON.stringify({ id, method, params }));
      });
    }

    async function evaluate(expression) {
      const res = await sendCommand('Runtime.evaluate', {
        expression,
        returnByValue: true,
        awaitPromise: true,
      });
      return res.result.value;
    }

    await sendCommand('Page.enable');
    await sendCommand('DOM.enable');
    await sendCommand('Page.navigate', { url: TARGET_URL });
    await wait(1500);

    const lightStyles = await evaluate(`(() => {
      const card = document.querySelector('.glass-card');
      const btn = document.querySelector('.btn-with-icon');
      const btnCircle = btn?.querySelector('.btn-icon-circle');
      const th = document.querySelector('.table-modern th');

      const cardStyle = window.getComputedStyle(card);
      const btnStyle = window.getComputedStyle(btn);
      const circleStyle = window.getComputedStyle(btnCircle);
      const thStyle = window.getComputedStyle(th);

      return {
        cardBg: cardStyle.backgroundImage,
        cardBackdropBlur: cardStyle.backdropFilter || cardStyle.webkitBackdropFilter,
        cardBorder: cardStyle.borderColor,
        btnBg: btnStyle.backgroundColor,
        btnText: btnStyle.color,
        circleBg: circleStyle.backgroundColor,
        circleText: circleStyle.color,
        thBg: thStyle.backgroundColor,
        thText: thStyle.color
      };
    })()`);

    console.log('[MONOCHROME] Light Mode Styles:', JSON.stringify(lightStyles, null, 2));

    // Toggle to Dark Mode
    await evaluate(`document.getElementById('btn-theme-toggle').click();`);
    await wait(400);

    const darkStyles = await evaluate(`(() => {
      const card = document.querySelector('.glass-card');
      const btn = document.querySelector('.btn-with-icon');
      const btnCircle = btn?.querySelector('.btn-icon-circle');
      const th = document.querySelector('.table-modern th');

      const cardStyle = window.getComputedStyle(card);
      const btnStyle = window.getComputedStyle(btn);
      const circleStyle = window.getComputedStyle(btnCircle);
      const thStyle = window.getComputedStyle(th);

      return {
        cardBg: cardStyle.backgroundImage,
        cardBackdropBlur: cardStyle.backdropFilter || cardStyle.webkitBackdropFilter,
        cardBorder: cardStyle.borderColor,
        btnBg: btnStyle.backgroundColor,
        btnText: btnStyle.color,
        circleBg: circleStyle.backgroundColor,
        circleText: circleStyle.color,
        thBg: thStyle.backgroundColor,
        thText: thStyle.color
      };
    })()`);

    console.log('[MONOCHROME] Dark Mode Styles:', JSON.stringify(darkStyles, null, 2));

    ws.close();
  } finally {
    if (!exited) chrome.kill('SIGTERM');
  }
}

run().catch(console.error);

