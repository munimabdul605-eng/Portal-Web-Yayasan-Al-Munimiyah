/**
 * verify-logo.js
 * Verifies logo rendering, transparency, and dark/light mode adaptation.
 */
const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PORT = 9224;
const TARGET_URL = 'http://localhost:3000/';

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => resolve(JSON.parse(data)));
    }).on('error', reject);
  });
}

async function run() {
  const chrome = spawn(
    CHROME_PATH,
    [
      '--headless=new',
      `--remote-debugging-port=${PORT}`,
      '--disable-gpu',
      '--no-first-run',
      'about:blank',
    ],
    { stdio: 'ignore' }
  );

  let exited = false;
  chrome.on('exit', () => { exited = true; });

  try {
    let version = null;
    for (let i = 0; i < 20; i++) {
      try {
        version = await getJson(`http://127.0.0.1:${PORT}/json/version`);
        if (version && version.webSocketDebuggerUrl) break;
      } catch (e) {}
      await wait(300);
    }

    const pages = await getJson(`http://127.0.0.1:${PORT}/json/list`);
    const targetPage = pages.find((p) => p.type === 'page') || pages[0];
    const ws = new WebSocket(targetPage.webSocketDebuggerUrl);

    let msgId = 1;
    const callbacks = new Map();
    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.id && callbacks.has(msg.id)) {
        const { resolve, reject } = callbacks.get(msg.id);
        callbacks.delete(msg.id);
        if (msg.error) reject(msg.error);
        else resolve(msg.result);
      }
    };

    await new Promise((resolve) => { ws.onopen = resolve; });

    function sendCommand(method, params = {}) {
      const id = msgId++;
      return new Promise((resolve, reject) => {
        callbacks.set(id, { resolve, reject });
        ws.send(JSON.stringify({ id, method, params }));
      });
    }

    async function evaluate(expression) {
      const res = await sendCommand('Runtime.evaluate', {
        expression,
        returnByValue: true,
        awaitPromise: true,
      });
      return res.result.value;
    }

    await sendCommand('Page.enable');
    await sendCommand('DOM.enable');
    await sendCommand('Emulation.setDeviceMetricsOverride', {
      width: 1280,
      height: 800,
      deviceScaleFactor: 2,
      mobile: false,
    });

    await sendCommand('Page.navigate', { url: TARGET_URL });
    await wait(1500);

    // 1. Audit Light Mode Logo
    const lightLogo = await evaluate(`(() => {
      const frame = document.querySelector('.header-logo-frame');
      const img = document.querySelector('.header-logo-img');
      const frameStyle = window.getComputedStyle(frame);
      const imgStyle = window.getComputedStyle(img);
      const rect = frame.getBoundingClientRect();
      const imgRect = img.getBoundingClientRect();

      return {
        src: img.src,
        naturalWidth: img.naturalWidth,
        naturalHeight: img.naturalHeight,
        frameBg: frameStyle.backgroundColor,
        frameBorder: frameStyle.borderWidth,
        imgFilter: imgStyle.filter,
        frameWidth: rect.width,
        frameHeight: rect.height,
        imgWidth: imgRect.width,
        imgHeight: imgRect.height
      };
    })()`);

    console.log('[LOGO AUDIT] Light Mode:', lightLogo);

    // Capture Light Mode Header Screenshot
    const lightShot = await sendCommand('Page.captureScreenshot', {
      format: 'png',
      clip: { x: 0, y: 0, width: 400, height: 80, scale: 2 }
    });
    fs.writeFileSync('scripts/header-light.png', Buffer.from(lightShot.data, 'base64'));
    console.log('[LOGO AUDIT] Captured scripts/header-light.png');

    // 2. Toggle to Dark Mode
    await evaluate(`document.getElementById('btn-theme-toggle').click();`);
    await wait(500);

    const darkLogo = await evaluate(`(() => {
      const frame = document.querySelector('.header-logo-frame');
      const img = document.querySelector('.header-logo-img');
      const frameStyle = window.getComputedStyle(frame);
      const imgStyle = window.getComputedStyle(img);

      return {
        frameBg: frameStyle.backgroundColor,
        imgFilter: imgStyle.filter,
        isDarkActive: document.documentElement.classList.contains('dark')
      };
    })()`);

    console.log('[LOGO AUDIT] Dark Mode:', darkLogo);

    // Capture Dark Mode Header Screenshot
    const darkShot = await sendCommand('Page.captureScreenshot', {
      format: 'png',
      clip: { x: 0, y: 0, width: 400, height: 80, scale: 2 }
    });
    fs.writeFileSync('scripts/header-dark.png', Buffer.from(darkShot.data, 'base64'));
    console.log('[LOGO AUDIT] Captured scripts/header-dark.png');

    const passLight = lightLogo.frameBg === 'rgba(0, 0, 0, 0)' && lightLogo.imgFilter.includes('brightness(0)');
    const passDark = darkLogo.frameBg === 'rgba(0, 0, 0, 0)' && darkLogo.imgFilter.includes('invert(1)');

    console.log('\n================== LOGO AUDIT SUMMARY ==================');
    console.log('1. Transparent Background (No solid box):', lightLogo.frameBg === 'rgba(0, 0, 0, 0)' ? 'PASS' : 'FAIL');
    console.log('2. Light Mode Color (Pure Black):', lightLogo.imgFilter.includes('brightness(0)') ? 'PASS' : 'FAIL');
    console.log('3. Dark Mode Color (Pure White):', darkLogo.imgFilter.includes('invert(1)') ? 'PASS' : 'FAIL');
    console.log('4. Dimensions & Aspect Ratio:', lightLogo.naturalWidth === 419 && lightLogo.naturalHeight === 657 ? 'PASS' : 'FAIL');
    console.log('========================================================\n');

    ws.close();
  } finally {
    if (!exited) chrome.kill('SIGTERM');
  }
}

run().catch(console.error);

