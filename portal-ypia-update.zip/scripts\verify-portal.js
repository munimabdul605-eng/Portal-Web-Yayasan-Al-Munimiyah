/**
 * verify-portal.js
 * End-to-end verification script for Portal YPIA using headless Chrome and native CDP.
 */
const { spawn } = require('child_process');
const http = require('http');

const CHROME_PATH = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const PORT = 9222;
const TARGET_URL = 'http://localhost:3000/';

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

async function run() {
  console.log('[VERIFY] Launching headless Chrome...');
  const chrome = spawn(
    CHROME_PATH,
    [
      '--headless=new',
      `--remote-debugging-port=${PORT}`,
      '--disable-gpu',
      '--no-first-run',
      '--no-default-browser-check',
      '--user-data-dir=' + require('os').tmpdir() + '\\chrome-test-' + Date.now(),
      'about:blank',
    ],
    { stdio: 'ignore' }
  );

  let exited = false;
  chrome.on('exit', () => {
    exited = true;
  });

  try {
    // Wait for Chrome CDP endpoint
    let version = null;
    for (let i = 0; i < 20; i++) {
      try {
        version = await getJson(`http://127.0.0.1:${PORT}/json/version`);
        if (version && version.webSocketDebuggerUrl) break;
      } catch (e) {}
      await wait(300);
    }

    if (!version) {
      throw new Error('Failed to connect to Chrome CDP after 6 seconds');
    }

    const pages = await getJson(`http://127.0.0.1:${PORT}/json/list`);
    const targetPage = pages.find((p) => p.type === 'page') || pages[0];
    const wsUrl = targetPage.webSocketDebuggerUrl;
    console.log('[VERIFY] Connecting to page WebSocket:', wsUrl);

    const ws = new WebSocket(wsUrl);
    let msgId = 1;
    const callbacks = new Map();
    const consoleLogs = [];
    const pageErrors = [];

    ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);
      if (msg.id && callbacks.has(msg.id)) {
        const { resolve, reject } = callbacks.get(msg.id);
        callbacks.delete(msg.id);
        if (msg.error) reject(msg.error);
        else resolve(msg.result);
      }
      if (msg.method === 'Runtime.consoleAPICalled') {
        const type = msg.params.type;
        const text = msg.params.args.map((a) => a.value || a.description || '').join(' ');
        consoleLogs.push({ type, text });
        if (type === 'error') {
          pageErrors.push(text);
        }
      }
      if (msg.method === 'Runtime.exceptionThrown') {
        pageErrors.push(msg.params.exceptionDetails.text || 'Uncaught exception');
      }
    };

    await new Promise((resolve, reject) => {
      ws.onopen = resolve;
      ws.onerror = reject;
    });

    function sendCommand(method, params = {}) {
      const id = msgId++;
      return new Promise((resolve, reject) => {
        callbacks.set(id, { resolve, reject });
        ws.send(JSON.stringify({ id, method, params }));
      });
    }

    async function evaluate(expression) {
      const res = await sendCommand('Runtime.evaluate', {
        expression,
        returnByValue: true,
        awaitPromise: true,
      });
      if (res.exceptionDetails) {
        throw new Error(res.exceptionDetails.text || 'Evaluation failed');
      }
      return res.result.value;
    }

    // Enable domains
    await sendCommand('Runtime.enable');
    await sendCommand('Page.enable');
    await sendCommand('DOM.enable');

    // Set Desktop Viewport
    await sendCommand('Emulation.setDeviceMetricsOverride', {
      width: 1280,
      height: 900,
      deviceScaleFactor: 1,
      mobile: false,
    });

    console.log('[VERIFY] Navigating to', TARGET_URL);
    await sendCommand('Page.navigate', { url: TARGET_URL });

    console.log('[VERIFY] Waiting for data to render...');
    await evaluate(`new Promise((resolve, reject) => {
      const start = Date.now();
      const interval = setInterval(() => {
        const pimpinan = document.querySelectorAll('#profil-struktur-grid article');
        const units = document.querySelectorAll('#unit-cards-grid article');
        const rows = document.querySelectorAll('#fee-master-tbody tr');
        if (pimpinan.length > 0 && units.length > 0 && rows.length >= 5) {
          clearInterval(interval);
          resolve(true);
        } else if (Date.now() - start > 10000) {
          clearInterval(interval);
          resolve(false);
        }
      }, 100);
    })`);

    console.log('[VERIFY] Performing comprehensive audit...');

    const audit = await evaluate(`(async () => {
      // 1. Data Alignment Verification
      const heroHeadline = document.querySelector('.nextra-headline')?.innerText?.trim();
      const heroSk = document.getElementById('hero-sk')?.innerText?.trim();
      const heroVisi = document.getElementById('hero-visi')?.innerText?.trim();
      const profilAddress = document.getElementById('profil-address')?.innerText?.trim();

      // Struktur pimpinan
      const pimpinanCards = document.querySelectorAll('#profil-struktur-grid article');
      const pimpinanList = Array.from(pimpinanCards).map(card => ({
        jabatan: card.querySelector('span')?.innerText?.trim(),
        nama: card.querySelector('h3')?.innerText?.trim()
      }));

      // Unit pendidikan cards
      const unitCards = document.querySelectorAll('#unit-cards-grid article');
      const unitList = Array.from(unitCards).map(card => ({
        nama: card.querySelector('.typo-h3')?.innerText?.trim(),
        jam: card.querySelectorAll('dd')[0]?.innerText?.trim(),
        tahfidz: card.querySelectorAll('dd')[1]?.innerText?.trim(),
        unggulan: card.querySelectorAll('dd')[2]?.innerText?.trim(),
        spp: card.querySelector('strong')?.innerText?.trim(),
        btnText: card.querySelector('a')?.innerText?.trim(),
        btnHref: card.querySelector('a')?.getAttribute('href')
      }));

      // Fee Table
      const feeRows = document.querySelectorAll('#fee-master-tbody tr');
      const feeList = Array.from(feeRows).map(row => {
        const cells = Array.from(row.querySelectorAll('td')).map(c => c.innerText.trim());
        return {
          nama: cells[0],
          formulir: cells[1],
          dpp: cells[2],
          paket: cells[3],
          spp: cells[4],
          awalMasuk: cells[5]
        };
      });

      // 2. Calculator Verification (MUST BE ABSENT)
      const calcUnit = document.getElementById('calc-unit');
      const calcWave = document.getElementById('calc-wave');
      const calcFormulir = document.getElementById('calc-res-formulir');

      // 3. Button & Arrow Icon Verification
      const activeBtns = Array.from(document.querySelectorAll('.btn-with-icon')).map(b => {
        const text = b.querySelector('span:not(.btn-icon-circle)')?.innerText?.trim() || b.innerText.trim();
        const circle = b.querySelector('.btn-icon-circle');
        const hasCircle = Boolean(circle);
        const svg = circle?.querySelector('svg');
        const line = svg?.querySelector('line');
        const polyline = svg?.querySelector('polyline');
        const isHorizontalArrow = line?.getAttribute('x1') === '5' &&
                                  line?.getAttribute('y1') === '12' &&
                                  line?.getAttribute('x2') === '19' &&
                                  line?.getAttribute('y2') === '12';
        const rect = b.getBoundingClientRect();
        const circleRect = circle?.getBoundingClientRect();
        return {
          text,
          hasCircle,
          isHorizontalArrow,
          btnHeight: rect.height,
          circleWidth: circleRect?.width,
          circleHeight: circleRect?.height,
          type: b.tagName
        };
      });

      // 4. Native PPDB Form Audit
      const ppdbForm = document.getElementById('ppdb-online-form');
      const hasForm = Boolean(ppdbForm);
      const action = ppdbForm?.getAttribute('action');
      const method = ppdbForm?.getAttribute('method');
      const target = ppdbForm?.getAttribute('target');

      // Form fields check
      const fieldStudent = Boolean(ppdbForm?.querySelector('[name="entry.8597841"]'));
      const fieldUnit = Array.from(ppdbForm?.querySelectorAll('[name="entry.886746899"]') || []).map(r => r.value);
      const fieldWave = Array.from(ppdbForm?.querySelectorAll('[name="entry.1502592928"]') || []).map(r => r.value);
      const fieldDiscount = Boolean(ppdbForm?.querySelector('[name="entry.1880708247"]'));
      const fieldTahfidz = Boolean(ppdbForm?.querySelector('[name="entry.447849860"]'));
      const fieldPayment = Array.from(ppdbForm?.querySelectorAll('[name="entry.1676886351"]') || []).map(r => r.value);
      const fieldParentName = Boolean(ppdbForm?.querySelector('[name="entry.2102236790"]'));
      const fieldParentPhone = Boolean(ppdbForm?.querySelector('[name="entry.1381684453"]'));

      const allFieldsPresent = fieldStudent &&
                               fieldUnit.length === 5 &&
                               fieldWave.length === 3 &&
                               fieldDiscount &&
                               fieldTahfidz &&
                               fieldPayment.length === 2 &&
                               fieldParentName &&
                               fieldParentPhone;

      // Standalone Full Form link check
      const fullFormLink = document.querySelector('a[href*="1yXFsxZxj3GBaQZ253uA516KGcuKR0bjGobmQpNedj_Y"]');
      const hasFullFormLink = Boolean(fullFormLink);

      // Check overflow on Desktop
      const desktopOverflow = document.documentElement.scrollWidth > document.documentElement.clientWidth;

      return {
        heroHeadline,
        heroSk,
        pimpinanCount: pimpinanList.length,
        unitCount: unitList.length,
        feeRowCount: feeList.length,
        calculatorEliminated: !calcUnit && !calcWave && !calcFormulir,
        activeBtnsCount: activeBtns.length,
        allBtnsHaveArrow: activeBtns.every(b => b.hasCircle && b.isHorizontalArrow),
        activeBtns,
        hasForm,
        action,
        method,
        target,
        allFieldsPresent,
        fieldUnit,
        fieldWave,
        fieldPayment,
        hasFullFormLink,
        desktopOverflow
      };
    })()`);

    console.log('[VERIFY] Audit results:', JSON.stringify(audit, null, 2));

    // 5. Test PPDB Interactive Features (Radio Click, Form Submit, Toggle)
    console.log('[VERIFY] Testing PPDB Form interactivity...');
    const ppdbInteractionTest = await evaluate(`(() => {
      const ppdbForm = document.getElementById('ppdb-online-form');
      const smaRadio = ppdbForm.querySelector('input[value="SMA"]');
      const smaCard = smaRadio?.closest('.form-radio-card');
      const sdRadio = ppdbForm.querySelector('input[value="SD"]');
      const sdCard = sdRadio?.closest('.form-radio-card');

      // Click SMA radio
      smaRadio.checked = true;
      smaRadio.dispatchEvent(new Event('change', { bubbles: true }));

      const smaSelected = smaCard.classList.contains('is-selected');
      const sdDeselected = !sdCard.classList.contains('is-selected');

      // Test Google Forms fallback iframe toggle
      const toggleBtn = document.getElementById('btn-toggle-google-frame');
      const fallbackWrap = document.getElementById('google-forms-fallback-wrapper');
      const iframeEl = document.getElementById('google-forms-iframe-el');

      toggleBtn.click();
      const toggledOpen = !fallbackWrap.classList.contains('hidden');
      const iframeHasSrc = Boolean(iframeEl.src && iframeEl.src.includes('1yXFsxZxj3GBaQZ253uA516KGcuKR0bjGobmQpNedj_Y'));

      toggleBtn.click();
      const toggledClosed = fallbackWrap.classList.contains('hidden');

      return {
        radioSelectionWorks: smaSelected && sdDeselected,
        toggleFallbackWorks: toggledOpen && toggledClosed && iframeHasSrc
      };
    })()`);
    console.log('[VERIFY] PPDB Interaction Test:', ppdbInteractionTest);

    // 6. Test Form Submission
    console.log('[VERIFY] Testing Form Submission simulation...');
    const formSubmitTest = await evaluate(`(() => {
      const ppdbForm = document.getElementById('ppdb-online-form');
      document.getElementById('ppdb-student-name').value = 'Test Calon Siswa';
      document.getElementById('ppdb-parent-name').value = 'Test Orang Tua';
      document.getElementById('ppdb-parent-phone').value = '081234567890';

      const submitEvent = new Event('submit', { cancelable: true, bubbles: true });
      ppdbForm.dispatchEvent(submitEvent);

      return new Promise((resolve) => {
        setTimeout(() => {
          const banner = document.getElementById('ppdb-success-banner');
          const isBannerVisible = !banner.classList.contains('hidden');
          const summaryText = document.getElementById('ppdb-success-summary')?.innerText || '';
          const waHref = document.getElementById('ppdb-wa-confirm-btn')?.getAttribute('href') || '';
          resolve({
            isBannerVisible,
            hasSummary: summaryText.includes('Test Calon Siswa'),
            hasWaLink: waHref.includes('6281122334455') && waHref.includes('Test+Calon+Siswa') || waHref.includes('Test%20Calon%20Siswa')
          });
        }, 750);
      });
    })()`);
    console.log('[VERIFY] Form Submit Test:', formSubmitTest);

    // 7. Test Theme Toggle
    console.log('[VERIFY] Testing Theme Toggle...');
    const themeTest = await evaluate(`(() => {
      const btn = document.getElementById('btn-theme-toggle');
      const initialDark = document.documentElement.classList.contains('dark');
      btn.click();
      const afterDark = document.documentElement.classList.contains('dark');
      btn.click();
      const revertedDark = document.documentElement.classList.contains('dark');
      return { initialDark, afterDark, revertedDark, success: initialDark !== afterDark && initialDark === revertedDark };
    })()`);
    console.log('[VERIFY] Theme toggle test:', themeTest);

    // 8. Test Modal Arsip Dokumen
    console.log('[VERIFY] Testing Arsip Dokumen Modal...');
    const modalTest = await evaluate(`(() => {
      const openBtn = document.getElementById('btn-drive-status');
      const modal = document.getElementById('drive-modal');
      const closeBtn = document.getElementById('btn-close-drive-modal');

      openBtn.click();
      const opened = !modal.classList.contains('hidden');
      const docItems = Array.from(modal.querySelectorAll('.modal-doc-item')).map(item => ({
        title: item.querySelector('.font-semibold')?.innerText?.trim(),
        url: item.querySelector('a')?.href
      }));
      const folderLink = document.getElementById('drive-folder-link')?.href;

      closeBtn.click();
      const closed = modal.classList.contains('hidden');

      return {
        opened,
        closed,
        docCount: docItems.length,
        docItems,
        folderLink,
        success: opened && closed && docItems.length === 5
      };
    })()`);
    console.log('[VERIFY] Modal test:', JSON.stringify(modalTest, null, 2));

    // 9. Test Mobile Viewport and Overflow
    console.log('[VERIFY] Testing Mobile Viewport (390x844)...');
    await sendCommand('Emulation.setDeviceMetricsOverride', {
      width: 390,
      height: 844,
      deviceScaleFactor: 3,
      mobile: true,
    });
    await wait(500);

    const mobileAudit = await evaluate(`(() => {
      const overflow = document.documentElement.scrollWidth > document.documentElement.clientWidth;
      const mobileBtn = document.getElementById('btn-mobile-menu');
      const mobileMenu = document.getElementById('mobile-menu');
      mobileBtn.click();
      const menuOpened = !mobileMenu.classList.contains('hidden');
      mobileBtn.click();
      const menuClosed = mobileMenu.classList.contains('hidden');
      return {
        mobileOverflow: overflow,
        mobileMenuToggle: menuOpened && menuClosed
      };
    })()`);
    console.log('[VERIFY] Mobile test:', mobileAudit);

    console.log('[VERIFY] Total Page Errors:', pageErrors.length);
    if (pageErrors.length > 0) {
      console.error('[VERIFY] Page errors detected:', pageErrors);
    }

    const allPassed =
      audit.feeRowCount === 5 &&
      audit.checklistCount === 12 &&
      audit.pimpinanCount === 10 &&
      audit.calculatorEliminated &&
      audit.allBtnsHaveArrow &&
      audit.hasForm &&
      audit.allFieldsPresent &&
      audit.hasFullFormLink &&
      ppdbInteractionTest.radioSelectionWorks &&
      ppdbInteractionTest.toggleFallbackWorks &&
      formSubmitTest.isBannerVisible &&
      formSubmitTest.hasSummary &&
      themeTest.success &&
      modalTest.success &&
      !audit.desktopOverflow &&
      !mobileAudit.mobileOverflow &&
      pageErrors.length === 0;

    console.log('\n================== SUMMARY ==================');
    console.log('1. Database Alignment (Pimpinan, Unit, Biaya):', audit.feeRowCount === 5 && audit.pimpinanCount === 10 ? 'PASS' : 'FAIL');
    console.log('2. Calculator Removed:', audit.calculatorEliminated ? 'PASS' : 'FAIL');
    console.log('3. All Buttons Have Horizontal Arrow Icon:', audit.allBtnsHaveArrow ? 'PASS' : 'FAIL');
    console.log('4. Native PPDB Form Has All 8 Exact Fields:', audit.allFieldsPresent ? 'PASS' : 'FAIL');
    console.log('5. Google Forms Post Target & Fallback Toggle:', ppdbInteractionTest.toggleFallbackWorks && audit.target === 'ppdb-hidden-iframe' ? 'PASS' : 'FAIL');
    console.log('6. Form Submission & In-Page Success Banner:', formSubmitTest.isBannerVisible && formSubmitTest.hasSummary ? 'PASS' : 'FAIL');
    console.log('7. External Standalone Links Preserved:', audit.hasFullFormLink && modalTest.success ? 'PASS' : 'FAIL');
    console.log('8. Zero Console Errors:', pageErrors.length === 0 ? 'PASS' : 'FAIL');
    console.log('9. Zero Horizontal Overflow (Desktop & Mobile):', !audit.desktopOverflow && !mobileAudit.mobileOverflow ? 'PASS' : 'FAIL');
    console.log('=============================================\n');

    ws.close();
  } finally {
    if (!exited) {
      chrome.kill('SIGTERM');
    }
  }
}

run().catch((err) => {
  console.error('[VERIFY ERROR]', err);
  process.exit(1);
});
