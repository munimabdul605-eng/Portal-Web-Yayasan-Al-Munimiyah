/**
 * Portal Web Terpadu Yayasan Pendidikan Islam Al-Mun'imiyah (SI-YAYASAN)
 * Server Node.js tanpa dependensi eksternal.
 *
 *   node server.js            -> jalankan portal (default http://localhost:3000)
 *   node server.js --sync     -> tarik dokumen terbaru dari folder Drive ke data/drive/
 *   node server.js --build    -> tulis public/data/kb.json (untuk hosting statis)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

try { process.loadEnvFile(path.join(__dirname, '.env')); } catch { /* .env opsional */ }

const { loadSources } = require('./lib/drive');
const { buildKnowledgeBase } = require('./lib/parse');
const assistant = require('./lib/assistant');

const PORT = Number(process.env.PORT) || 3000;
const CACHE_TTL = (Number(process.env.CACHE_TTL_MINUTES) || 10) * 60 * 1000;
const PUBLIC = path.join(__dirname, 'public');

let state = { kb: null, sources: null, loadedAt: 0, loading: null };

async function getKB(force = false) {
  if (!force && state.kb && Date.now() - state.loadedAt < CACHE_TTL) return state;
  if (state.loading) return state.loading;
  state.loading = (async () => {
    try {
      const sources = await loadSources();
      const kb = buildKnowledgeBase(sources);
      kb.ai.engine = process.env.GEMINI_API_KEY ? 'gemini' : 'local';
      state = { kb, sources, loadedAt: Date.now(), loading: null };
      const modes = [...new Set(Object.values(sources).map((s) => s.source))].join(', ');
      console.log(`[KB] Knowledge base dimuat (${modes}) — ${new Date().toLocaleTimeString('id-ID')}`);
    } catch (err) {
      state.loading = null;
      if (!state.kb) throw err;
      console.error('[KB] Gagal memperbarui, memakai cache lama:', err.message);
    }
    return state;
  })();
  return state.loading;
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.webp': 'image/webp' };

function send(res, code, body, type = 'application/json; charset=utf-8') {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}

function readBody(req, limit = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => { data += c; if (data.length > limit) { reject(new Error('Payload terlalu besar')); req.destroy(); } });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  try {
    if (url.pathname === '/api/kb' && req.method === 'GET') {
      const { kb } = await getKB(url.searchParams.has('refresh'));
      return send(res, 200, kb);
    }
    if (url.pathname === '/api/chat' && req.method === 'POST') {
      const body = await readBody(req);
      const message = String(body.message || '').trim().slice(0, 2000);
      if (!message) return send(res, 400, { error: 'Pesan kosong' });
      const history = Array.isArray(body.history) ? body.history.filter((h) => h && typeof h.content === 'string').slice(-12) : [];
      const { kb, sources } = await getKB();
      const out = await assistant.answer(kb, sources, message, history);
      return send(res, 200, out);
    }
    if (url.pathname === '/api/health') return send(res, 200, { ok: true, engine: process.env.GEMINI_API_KEY ? 'gemini' : 'local' });

    // Static files
    let p = decodeURIComponent(url.pathname);
    if (p === '/') p = '/index.html';
    const file = path.normalize(path.join(PUBLIC, p));
    if (!file.startsWith(PUBLIC)) return send(res, 403, 'Forbidden', 'text/plain');
    fs.readFile(file, (err, buf) => {
      if (err) return fs.readFile(path.join(PUBLIC, 'index.html'), (e2, html) => (e2 ? send(res, 404, 'Not found', 'text/plain') : send(res, 200, html, MIME['.html'])));
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      res.end(buf);
    });
  } catch (err) {
    console.error(err);
    send(res, 500, { error: err.message });
  }
});

(async () => {
  const args = process.argv.slice(2);
  if (args.includes('--sync')) {
    const sources = await loadSources({ mode: 'live', saveSnapshot: true });
    console.log('Sinkronisasi selesai:', Object.values(sources).map((s) => s.name).join(', '));
    return;
  }
  if (args.includes('--build')) {
    const { kb } = await getKB(true);
    fs.mkdirSync(path.join(PUBLIC, 'data'), { recursive: true });
    fs.writeFileSync(path.join(PUBLIC, 'data', 'kb.json'), JSON.stringify(kb));
    console.log('public/data/kb.json ditulis.');
    return;
  }
  await getKB(true);
  server.listen(PORT, () => {
    console.log(`\n  Portal YPIA berjalan di  http://localhost:${PORT}`);
    console.log(`  Asisten AI             : ${process.env.GEMINI_API_KEY ? `Gemini (${process.env.GEMINI_MODEL || 'gemini-2.5-flash'})` : 'mesin lokal (set GEMINI_API_KEY untuk Gemini)'}\n`);
  });
})().catch((err) => { console.error(err); process.exit(1); });

